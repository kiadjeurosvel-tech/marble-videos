import bpy, json, math, sys, os
from mathutils import Vector, Euler

bpy.ops.wm.open_mainfile(filepath='/kaggle/tmp/c/ep/scene.blend')
O = bpy.data.objects
TL = json.load(open('/kaggle/tmp/c/ep/timeline.json'))
C = TL['clips']; ENV = TL['env']; TOTAL = TL['total']
pi = math.pi
sin, cos = math.sin, math.cos


def k0(k): return C[k]['t0']
def k1(k): return C[k]['t1']
def E(sp, t):
    a = ENV[sp]; i = int(t * 100)
    return a[i] if 0 <= i < len(a) else 0.0
def ease(u): u = min(1, max(0, u)); return u * u * (3 - 2 * u)
def lerp(a, b, u): return [x + (y - x) * u for x, y in zip(a, b)]
def V(*a): return Vector(a)


def upd(): bpy.context.view_layer.update()


# ------------------------------------------------------------- posing
def P(**kw):
    d = dict(loc=(0, 0, -50), yaw=0, lie=0, walk=None, amp=0.45, arm={}, leg={}, spine=0, twist=0,
             head=(0, 0, 0), eo=1.0, brow=(0, 0), mouth=0, sit=0)
    d.update(kw); return d


def pose(nm, p):
    root = O[nm + '_root']
    if p is None:
        root.location = (0, 0, -50); return
    root.location = p['loc']; root.rotation_euler = (p['lie'], 0, p['yaw'])
    A = p['amp']; th = {'L': 0, 'R': 0}; kn = {'L': 0, 'R': 0}; arm = {'L': [0, 0.08, 0.15], 'R': [0, 0.08, 0.15]}
    bob = 0
    if p['walk'] is not None:
        ph = p['walk']
        th['L'] = A * sin(ph); th['R'] = -A * sin(ph)
        kn['L'] = A * 1.3 * max(0, sin(ph + 1.3)); kn['R'] = A * 1.3 * max(0, sin(ph + 1.3 + pi))
        arm['L'][0] = -0.8 * A * sin(ph); arm['R'][0] = 0.8 * A * sin(ph)
        arm['L'][2] = arm['R'][2] = 0.35
        bob = 0.025 * abs(cos(ph))
    if p['sit']:
        s = p['sit']; th['L'] = th['R'] = 1.45 * s; kn['L'] = kn['R'] = 1.45 * s
    for side, v in p['leg'].items():
        th[side], kn[side] = v
    for side, v in p['arm'].items():
        arm[side] = list(v)
    O[nm + '_hips'].location = (0, 0, 0.85 + bob - 0.42 * p['sit'] * 0.0)
    for side, sg in (('L', 1), ('R', -1)):
        f, o, e = arm[side]
        O['%s_sh%s' % (nm, side)].rotation_euler = (-f, -o * sg, 0)
        O['%s_el%s' % (nm, side)].rotation_euler = (-e, 0, 0)
        O['%s_hip%s' % (nm, side)].rotation_euler = (-th[side], 0, 0)
        O['%s_kn%s' % (nm, side)].rotation_euler = (kn[side], 0, 0)
    O[nm + '_spine'].rotation_euler = (p['spine'], 0, p['twist'])
    hp, hy, hr = p['head']
    O[nm + '_head'].rotation_euler = (hp, hr, hy)
    for sg in (1, -1):
        O['%s_eye%d' % (nm, sg)].scale = (1, 1, max(0.08, p['eo']))
        b = O['%s_brow%d' % (nm, sg)]
        b.rotation_euler = (0, p['brow'][0] * sg, 0)
        b.location.z = 0.315 + p['brow'][1] + 0.02 * (p['eo'] - 1)
    m = min(1, p['mouth'])
    O[nm + '_mouth'].scale = (1 - 0.25 * m, 1, 1 + 3.2 * m)


def headp(nm):
    upd(); return O[nm + '_skull'].matrix_world.translation.copy()
def handp(nm, s='R'):
    upd(); return O['%s_hand%s' % (nm, s)].matrix_world.translation.copy()


def place_phone(nm, pos, look_at=None, normal=None, up=V(0, 0, 1)):
    o = O[nm]; o.location = pos
    n = (look_at - pos) if look_at is not None else normal
    n = n.normalized()
    q = n.to_track_quat('Z', 'Y')
    o.rotation_euler = q.to_euler()


def ui(nm, state, on=1.0, wave=0.0, t=0.0):
    for k in ('rec4', 'rec5', 'wave', 'maman'):
        g = O['%s_%s' % (nm, k)]
        vis = (k == state)
        for c in g.children:
            c.hide_render = not vis
    bpy.data.materials[nm + '_screen'].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value = 2.2 * on
    O[nm + '_glow'].data.energy = 0.25 * on
    if state == 'wave':
        for i in range(9):
            O['%s_bar%d' % (nm, i)].scale.y = 0.03 * (0.15 + wave * (0.5 + 0.5 * sin(t * 23 + i * 1.7)) * (1 - abs(i - 4) / 6))


def cam(pos, tgt, lens=35, roll=0, shake=0, t=0):
    c = O['cam']; pos = V(*pos); tgt = V(*tgt)
    if shake:
        pos = pos + V(sin(t * 13) * shake, cos(t * 11) * shake, sin(t * 17) * shake * 0.6)
    c.location = pos
    q = (tgt - pos).to_track_quat('-Z', 'Y')
    e = q.to_euler(); c.rotation_euler = e
    if roll:
        c.rotation_euler.rotate_axis('Z', roll)
    c.data.lens = lens


def campath(p0, p1, t0, t1, u, lens=35, lens1=None, roll=0, shake=0, t=0):
    w = ease(u)
    cam(lerp(p0, p1, w), lerp(t0, t1, w), lens if lens1 is None else lens + (lens1 - lens) * w, roll, shake, t)


def dirq(d):
    return V(*d).normalized().to_track_quat('-Z', 'Y').to_euler()


def preset(name):
    w = bpy.data.worlds['W'].node_tree.nodes['Background']
    sun = O['sun']
    cfg = {
        'night': ((0.012, 0.018, 0.04), 1.1, (0.55, 0.65, 1.0), (30, -140, -45), 0.16, 0.12),
        'dawn': ((0.11, 0.12, 0.14), 1.1, (1.0, 0.78, 0.62), (-60, -50, -14), 0.55, 0.7),
        'uw': ((0.005, 0.03, 0.03), 0.0, (1, 1, 1), (0, 0, -1), 0.5, 0.25),
        'road': ((0.11, 0.12, 0.14), 1.0, (1.0, 0.78, 0.62), (-60, -50, -14), 0.6, 0.8),
        'busday': ((0.12, 0.13, 0.15), 1.4, (1.0, 0.85, 0.7), (-40, 30, -20), 0.3, 0.6),
        'city': ((0.03, 0.03, 0.07), 0.3, (0.6, 0.5, 1.0), (10, 10, -10), 0.0, 0.1),
        'indoor': ((0.01, 0.01, 0.01), 0.0, (1, 1, 1), (0, 0, -1), 0.0, 0.1),
    }[name]
    w.inputs['Color'].default_value = (*cfg[0], 1)
    O['camfill'].data.energy = {'night': 22, 'dawn': 8, 'uw': 6, 'road': 8, 'busday': 8, 'city': 15, 'indoor': 14}[name]
    O['camfill'].data.color = {'night': (0.6, 0.7, 1.0), 'uw': (0.4, 0.9, 0.9), 'city': (0.8, 0.75, 1.0)}.get(name, (1.0, 0.92, 0.85))
    sun.data.energy = cfg[1]; sun.data.color = cfg[2]; sun.rotation_euler = dirq(cfg[3])
    for f in ('fogA', 'fogR', 'fogR2', 'fogU', 'fogU2'):
        m = bpy.data.materials[f].node_tree.nodes
        if f in ('fogA',):
            m['dens'].inputs[1].default_value = cfg[4]
            m['fogem'].inputs['Strength'].default_value = cfg[5]
            m['fogem'].inputs['Color'].default_value = (0.3, 0.35, 0.45, 1) if name == 'night' else (0.75, 0.75, 0.78, 1)
        if f in ('fogR', 'fogR2'):
            m['fogem'].inputs['Strength'].default_value = cfg[5]


def water(bump=0.25, t=0.0):
    n = bpy.data.materials['water'].node_tree.nodes
    n['wbump'].inputs['Strength'].default_value = bump
    n['wnoise'].inputs['W'].default_value = t * 0.25


def hide_misc():
    for nm in ('meyep1', 'meyep-1', 'mbody', 'arm1', 'arm2', 'splash'):
        O[nm].location = (0, 0, -50)
    O['meyel'].data.energy = 0
    for i in range(14): O['bub%d' % i].location = (0, 0, -50)
    for i in range(10):
        O['drop%d' % i].location = (0, 0, -50); O['hdrop%d' % i].location = (0, 0, -50)
    O['bus'].location = (900, 0, 0)
    O['lanternl'].data.energy = 0
    O['lanternm'].hide_render = True
    O['bi_trees'].location = (300, 0, -50); O['bi_city'].location = (300, 0, -50)
    O['doorh'].rotation_euler = (0, 0, 0)
    for nm in ('phH', 'phW'):
        O[nm].location = (0, 0, -60); O[nm + '_glow'].data.energy = 0


def eyes(pos, s=1.0, glow=25):
    for sg in (1, -1):
        e = O['meyep%d' % sg]; e.location = V(*pos) + V(0.09 * sg * s, 0, 0); e.scale = (s, s, s)
    bpy.data.materials['redeye'].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value = glow
    O['meyel'].location = V(*pos) + V(0, -0.2, 0.1); O['meyel'].data.energy = glow * 0.12


# ------------------------------------------------------------- shared positions
H0 = V(0, 0.75, 0)        # hero on the bank, facing the river (+Y)
M0 = V(-1.3, -3.4, 0)     # Mami behind him
HEAD_H = 1.35
PHONE_ARM = {'R': (0.35, -0.3, 1.35)}
LANTERN = {'R': (0.35, 0.12, 0.25)}


def hero_phone(t, look_down=0.45, eo=1.0, brow=(0, 0), mouth=0, extra=None, yaw=pi):
    p = P(loc=H0, yaw=yaw, arm=dict(PHONE_ARM), head=(look_down, 0, 0), eo=eo, brow=brow, mouth=mouth, spine=0.08)
    if extra: p.update(extra)
    return p


def mami_stand(loc, yaw, **kw):
    d = dict(loc=loc, yaw=yaw, arm=dict(LANTERN), spine=0.1, head=(0.05, 0, 0))
    d.update(kw); return P(**d)


def face_cam(nm, dist, side=0.0, up=0.0, lens=50, push=0.0, u=0, yawoff=0.0):
    h = headp(nm); r = O[nm + '_root']
    yaw = r.rotation_euler.z + O[nm + '_head'].rotation_euler.z * 0 + yawoff
    fwd = V(sin(yaw), -cos(yaw), 0); right = V(cos(yaw), sin(yaw), 0)
    d = dist * (1 - push * ease(u))
    pos = h + fwd * d + right * side + V(0, 0, up)
    cam(pos, h + V(0, 0, -0.02), lens)


def phone_cam(nm, dist=0.22, u=0, push=0.25, side=0.0, lens=40):
    upd()
    o = O[nm]; m = o.matrix_world
    n = (m.to_3x3() @ V(0, 0, 1)).normalized(); upv = (m.to_3x3() @ V(0, 1, 0)).normalized()
    sidev = n.cross(upv)
    d = dist * (1 - push * ease(u))
    pos = m.translation + n * d + sidev * side
    c = O['cam']; c.location = pos
    q = (m.translation - pos).to_track_quat('-Z', 'Y'); c.rotation_euler = q.to_euler()
    # align camera up with phone up
    c.data.lens = lens
    cq = (m.translation - pos).normalized()
    c.rotation_euler = (-cq).to_track_quat('Z', 'Y').to_euler()
    import mathutils
    rot = mathutils.Matrix((sidev, upv, -cq)).transposed() if False else None
    mm = mathutils.Matrix.Identity(3)
    zc = (pos - m.translation).normalized(); yc = (upv - zc * upv.dot(zc)).normalized(); xc = yc.cross(zc)
    mm.col[0] = xc; mm.col[1] = yc; mm.col[2] = zc
    c.rotation_euler = mm.to_euler()


def walkph(dist, sc=0.8):
    return dist / (0.55 * sc) * pi


# ------------------------------------------------------------- shots
SH = []
def shot(a, b):
    def deco(f): SH.append((a, b, f)); return f
    return deco




T_ATT = k1('trop') + 0.45
T_DEAD = k0('matin') - 1.7
T_REW0 = k0('sijete') - 1.2
T_REW1 = k0('sijete') + 0.35


@shot(0, k0('pouce'))
def s01(t, u):
    preset('night'); water(0.25, t)
    pose('hero', hero_phone(t, 0.55, 1.0, (0.15, 0.0)))
    upd()
    place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'rec4', 1, t=t)
    eyes((0.45, 2.9, -0.13), 1.4, 15 + 40 * ease(u * 1.5))
    campath((0.95, 0.15, 1.35), (0.8, 0.45, 1.3), (0.3, 2.6, -0.05), (0.4, 2.8, -0.1), u, 26, 32)


@shot(k0('pouce'), k0('voix'))
def s02(t, u):
    preset('night'); water(0.25, t)
    w = ease((u - 0.25) / 0.35)
    p = hero_phone(t, 0.6, 1.0, (0.1, 0))
    p['arm']['L'] = (0.9 * w, 0.35 * w, 1.6 * w)
    pose('hero', p); upd()
    place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero'))
    ui('phH', 'rec4' if u < 0.62 else 'wave', 1, 0.2, t)
    phone_cam('phH', 0.28, u, 0.3, 0.03, 35)


@shot(k0('voix'), k0('mpetit') + 0.15)
def s03(t, u):
    preset('night'); water(0.25, t)
    eo = 1.0 + 0.35 * ease(u * 2)
    pose('hero', hero_phone(t, 0.1, eo, (0.25, 0.02))); upd()
    place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'wave', 1, 0.1, t)
    face_cam('hero', 0.95, 0.15, -0.05, 40, 0.2, u)


@shot(k0('mpetit') + 0.15, k0('derriere'))
def s04(t, u):
    preset('night'); water(0.25, t)
    pose('hero', hero_phone(t, 0.5, 1.3, (0.25, 0.02))); upd()
    place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero'))
    ui('phH', 'wave', 1, E('M', t) * 1.4, t)
    phone_cam('phH', 0.24, u, 0.25, -0.02, 38)


@shot(k0('derriere'), k0('oui'))
def s05(t, u):
    preset('night'); water(0.25, t)
    pose('hero', hero_phone(t, 0.3, 1.3, (0.25, 0.02), extra={'head': (0.25, -0.25 * ease(u), 0)}))
    pose('mami', mami_stand(M0, math.atan2((H0 - M0).x, -(H0 - M0).y), eo=0.9, brow=(0.3, 0.02)))
    O['lanternl'].data.energy = 6; O['lanternm'].hide_render = False
    upd()
    place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'wave', 1, 0.1, t)
    hh = headp('hero'); mh = headp('mami')
    campath((1.0, 1.8, 1.3), (0.9, 2.2, 1.45), hh + V(0, 0, 0), mh + V(0, 0, -0.1), u, 32, 40)


@shot(k0('oui'), k0('non'))
def s06(t, u):
    preset('night'); water(0.25, t)
    pose('hero', hero_phone(t, 0.08, 0.75, (0.35, -0.01), E('N', t)))
    upd(); place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'wave', 1, 0.1, t)
    face_cam('hero', 0.95, -0.15, -0.05, 40, 0.15, u)


@shot(k0('non'), k0('repondu'))
def s07(t, u):
    preset('night'); water(0.25, t)
    M1 = V(-0.65, -0.45, 0)
    w = ease(u * 1.2); pos = M0.lerp(M1, w)
    yaw = math.atan2((M1 - M0).x, -(M1 - M0).y)
    p = mami_stand(pos, yaw, walk=walkph((pos - M0).length * 1.0, 0.86), amp=0.6, eo=1.35, brow=(0.35, 0.03), mouth=E('M', t), spine=0.2)
    p['arm']['L'] = (1.3, 0.1, 0.2)
    pose('mami', p)
    pose('hero', hero_phone(t, 0.2, 1.0, (0.3, 0)))
    O['lanternl'].data.energy = 6; O['lanternm'].hide_render = False
    upd(); place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'wave', 1, 0.0, t)
    mh = headp('mami')
    cam(mh + V(-0.9, 1.7, -0.05), mh + V(0, 0, -0.15), 28, shake=0.02, t=t)


@shot(k0('repondu'), k0('encore'))
def s08(t, u):
    preset('night'); water(0.25, t)
    M1 = V(-0.65, -0.45, 0)
    yaw = math.atan2((H0 - M1).x, -(H0 - M1).y)
    w = ease(u * 2)
    p = mami_stand(M1, yaw, eo=1.4, brow=(0.4, 0.03), spine=0.15)
    p['arm']['L'] = (2.2 * w, -0.45 * w, 2.3 * w)
    pose('mami', p)
    pose('hero', hero_phone(t, 0.2, 0.8, (0.3, 0)))
    O['lanternl'].data.energy = 6; O['lanternm'].hide_render = False
    upd(); place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'wave', 1, 0.0, t)
    face_cam('mami', 1.25, 0.25, 0.0, 38, 0.2, u)


@shot(k0('encore'), k0('lisse'))
def s09(t, u):
    preset('night'); water(0.25 * (1 - u), t)
    M1 = V(-0.65, -0.45, 0)
    p = mami_stand(M1, math.atan2((H0 - M1).x, -(H0 - M1).y), eo=1.4, brow=(0.4, 0.03))
    p['arm']['L'] = (2.2, -0.45, 2.3); pose('mami', p)
    pose('hero', hero_phone(t, 0.2, 0.8, (0.3, 0)))
    O['lanternl'].data.energy = 6; O['lanternm'].hide_render = False
    upd(); place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'wave', 0.6, 0.0, t)
    campath((5.5, 9.0, 1.2), (4.8, 8.0, 1.0), (0, 0.5, 0.8), (0, 0.6, 0.8), u, 30, 34)


@shot(k0('lisse'), k0('trop'))
def s10(t, u):
    preset('night'); water(0.12 * (1 - ease(u)), t)
    pose('hero', hero_phone(t, 0.2, 0.8, (0.3, 0)))
    upd(); place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'wave', 0.6, 0.0, t)
    campath((1.5, 5.0, 0.05), (1.0, 4.0, 0.08), (0.3, 1.5, -0.05), (0.1, 1.0, 0.25), u, 24, 26)


@shot(k0('trop'), T_ATT)
def s11(t, u):
    preset('night'); water(0.0, t)
    eyes((0.4, 2.4, -0.17), 1.0 + 0.4 * u, 4 + 30 * ease(u * 1.5))
    O['mbody'].location = (0.4, 3.4, -0.55); O['mbody'].rotation_euler = (0, 0, 0)
    campath((0.4, 3.8, 0.25), (0.4, 3.3, 0.2), (0.4, 2.4, -0.15), (0.4, 2.4, -0.17), u, 32, 40)


@shot(T_ATT, T_ATT + 0.85)
def s12(t, u):
    preset('night'); water(0.3, t)
    pose('hero', hero_phone(t, 0.3, 1.4, (0.35, 0.03), extra={'spine': -0.1}))
    eyes((0.4, 2.4, -0.17), 1.3, 30)
    w = ease(u * 1.4)
    for a, (x, rz) in ((1, (-0.25, 0.3)), (2, (0.3, -0.3))):
        o = O['arm%d' % a]; o.location = (x, 1.75, -0.6 + 1.1 * w); o.rotation_euler = (0.7 - 0.6 * w, rz, 0)
    O['splash'].location = (0, 1.75, -0.1); O['splash'].scale = (1 + 3 * u, 1 + 3 * u, 1)
    upd(); place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'wave', 1, 0.0, t)
    cam((1.7, -0.5, 0.55), (0.0, 1.4, 0.6), 22, shake=0.04, t=t)


@shot(T_ATT + 0.85, T_ATT + 1.75)
def s13(t, u):
    preset('night'); water(0.3, t)
    w = ease(u * 1.5)
    p = P(loc=(0, 0.75 + 0.3 * w, 0.1 * w), yaw=pi, lie=-1.4 * w, arm={'L': (2.6 * w, 0.3, 0.3), 'R': (2.4 * w, 0.3, 0.4)},
          eo=1.45, brow=(0.4, 0.04), mouth=0.8 * w, head=(-0.3 * w, 0, 0))
    pose('hero', p)
    for a, x in ((1, -0.12), (2, 0.12)):
        o = O['arm%d' % a]; o.location = (x, 1.65, -0.35); o.rotation_euler = (-1.1, 0, 0)
    eyes((0.2, 2.6, -0.15), 1.3, 30)
    O['phW'].location = (0.4, 0.2, 0.01); O['phW'].rotation_euler = (0, 0, 0.4); ui('phW', 'wave', 0.8, 0, t)
    cam((-1.8, -0.8, 1.2), (0.0, 1.0, 0.2), 26, shake=0.05, t=t)


@shot(T_ATT + 1.75, T_DEAD)
def s14(t, u):
    preset('night'); water(0.35, t)
    w = ease(u)
    p = P(loc=(0, 1.1 + 2.0 * w, 0.1 - 0.9 * w), yaw=pi, lie=-1.45, arm={'L': (2.9, 0.4, 0.2), 'R': (2.9, 0.2, 0.3)},
          eo=1.45, brow=(0.4, 0.04), mouth=0.9, head=(-0.4, 0, 0))
    pose('hero', p)
    for a, x in ((1, -0.12), (2, 0.12)):
        o = O['arm%d' % a]; o.location = (x, 1.95 + 2.0 * w, -0.4 - 0.5 * w); o.rotation_euler = (-1.3, 0, 0)
    O['splash'].location = (0, 2.3 + 1.5 * w, -0.1); O['splash'].scale = (1 + 4 * u, 1 + 4 * u, 1)
    for i in range(10):
        a = i / 10 * 2 * pi; r = 0.3 + 1.2 * u
        O['drop%d' % i].location = (cos(a) * r, 2.5 + 1.5 * w + sin(a) * r, 0.6 * sin(pi * min(1, u * 1.3)) * (0.6 + (i % 3) * 0.3))
    O['phW'].location = (0.4, 0.2, 0.01); O['phW'].rotation_euler = (0, 0, 0.4); ui('phW', 'wave', 0.8, 0, t)
    cam((-1.5, -1.6, 1.4), (0.0, 2.2, 0.0), 24, shake=0.04, t=t)


@shot(T_DEAD, k0('matin'))
def s15(t, u):
    preset('night'); water(0.4, t)
    for i in range(14):
        ph = (t * 0.9 + i * 0.37) % 1
        O['bub%d' % i].location = (0.1 * sin(i * 3) + 0.15 * cos(i), 3.2 + 0.2 * cos(i * 2), -0.6 + 0.55 * ph)
    eyes((0.0, 3.6, -0.35), 1.2, 18 * (1 - u))
    campath((0.0, 1.3, 1.6), (0.0, 1.6, 1.3), (0.0, 3.3, -0.2), (0.0, 3.3, -0.25), u, 30, 34)


@shot(k0('matin'), k0('trouve'))
def s16(t, u):
    preset('dawn'); water(0.15, t)
    a = V(-6, -0.2, 0); b = V(-1.0, 0.1, 0)
    pos = a.lerp(b, u)
    pose('mami', P(loc=pos, yaw=pi / 2, walk=walkph((pos - a).length, 0.86), amp=0.3, spine=0.18, head=(0.25, 0.3, 0), eo=0.6, brow=(0.35, 0)))
    O['phW'].location = (0.4, 0.2, 0.01); O['phW'].rotation_euler = (0, 0, 0.4); ui('phW', 'rec5', 0.0)
    campath((-2.5, -6.5, 1.5), (-1.5, -5.6, 1.4), (-4.0, 0, 1.0), (-1.5, 0.2, 1.0), u, 32, 36)


@shot(k0('trouve'), k0('cinq'))
def s17(t, u):
    preset('dawn'); water(0.15, t)
    w = ease(u * 1.4)
    p = P(loc=(-0.2, 0.0, 0), yaw=1.89, spine=0.2 + 0.7 * w, head=(0.4, 0, 0), eo=0.8, brow=(0.35, 0.01),
          arm={'R': (0.4 + 0.7 * w, 0.1, 0.2), 'L': (0.2, 0.1, 0.3)}, leg={'L': (0.35 * w, 0.6 * w), 'R': (0.35 * w, 0.6 * w)})
    p['loc'] = (-0.2, 0.0, -0.1 * w)
    pose('mami', p)
    O['phW'].location = (0.4, 0.2, 0.01); O['phW'].rotation_euler = (0, 0, 0.4); ui('phW', 'rec5', 1.0 if u > 0.3 else 0.0)
    campath((1.5, -1.3, 1.0), (1.3, -1.1, 0.9), (0.2, 0.15, 0.5), (0.1, 0.1, 0.6), u, 26, 30)


@shot(k0('cinq'), k0('tavoix'))
def s18(t, u):
    preset('dawn'); water(0.15, t)
    O['phW'].location = (0.4, 0.2, 0.01); O['phW'].rotation_euler = (0, 0, 0.4); ui('phW', 'rec5', 1.0)
    upd(); phone_cam('phW', 0.26, u, 0.3, 0.0, 38)


@shot(k0('tavoix'), k0('viens') + 0.5)
def s19(t, u):
    preset('dawn'); water(0.15, t)
    pose('mami', P(loc=(-0.2, 0.0, 0), yaw=1.89, spine=0.35, head=(0.1, 0, 0), eo=1.0 + 0.4 * ease(u), brow=(0.4, 0.03),
                   arm={'R': (1.0, -0.2, 1.4), 'L': (0.2, 0.1, 0.3)}))
    upd()
    place_phone('phW', handp('mami') + V(0, 0, 0.04), look_at=headp('mami')); ui('phW', 'wave', 1.0, E('N', t) * 1.2, t)
    face_cam('mami', 1.15, 0.1, 0.0, 40, 0.25, u)


@shot(k0('viens') + 0.5, T_REW0)
def s20(t, u):
    preset('dawn'); water(0.1, t)
    pose('mami', P(loc=(-0.2, 0.0, 0), yaw=1.89, spine=0.35, head=(0.1, 0, 0), eo=1.4, brow=(0.4, 0.03),
                   arm={'R': (1.0, -0.2, 1.4), 'L': (0.2, 0.1, 0.3)}))
    O['mbody'].location = (0.0, 2.6 - 0.6 * u, -0.6); O['mbody'].rotation_euler = (0, 0, 0)
    eyes((0.0, 2.1 - 0.5 * u, -0.25), 1.2, 18)
    upd(); place_phone('phW', handp('mami') + V(0, 0, 0.04), look_at=headp('mami')); ui('phW', 'wave', 1.0, E('N', t), t)
    campath((1.8, 4.4, 0.6), (1.4, 3.8, 0.5), (0.2, 1.6, -0.2), (-0.1, 0.6, 0.6), u, 26, 30)


# -------- choice B
M2 = V(-0.75, -0.2, 0)


def scene_b(t, eo=1.0, hero_extra=None, mami_extra=None, phone=True):
    preset('night'); water(0.25, t)
    hp = hero_phone(t, 0.3, eo, (0.25, 0.01))
    if hero_extra: hp.update(hero_extra)
    pose('hero', hp)
    mp = mami_stand(M2, math.atan2((H0 - M2).x, -(H0 - M2).y), eo=1.1, brow=(0.3, 0.02))
    if mami_extra: mp.update(mami_extra)
    pose('mami', mp)
    O['lanternl'].data.energy = 6; O['lanternm'].hide_render = False
    upd()
    if phone:
        place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'rec4', 1, 0, t)


@shot(T_REW1, k0('jette'))
def s21(t, u):
    scene_b(t)
    campath((2.6, 4.5, 1.6), (2.0, 3.6, 1.5), (-0.3, 0.2, 1.1), (-0.3, 0.3, 1.2), u, 28, 32)


@shot(k0('jette'), k0('jette') + 1.6)
def s22(t, u):
    scene_b(t, mami_extra=dict(mouth=E('M', t), brow=(-0.2, 0.0), eo=0.85, head=(0.0, 0.0, 0)))
    face_cam('mami', 1.2, -0.2, 0.0, 40, 0.2, u)


@shot(k0('jette') + 1.6, k0('elan'))
def s23(t, u):
    scene_b(t, mami_extra=dict(mouth=E('M', t), brow=(0.2, 0.0), eo=0.9))
    eyes((1.2, 4.0, -0.2), 1.0, 10 * ease(u))
    hh = headp('hero')
    campath(hh + V(-0.5, -0.9, 0.25), hh + V(-0.4, -0.7, 0.25), (0.8, 4.0, -0.1), (1.0, 4.0, -0.1), u, 30, 34)


@shot(k0('elan'), k0('coule'))
def s24(t, u):
    w = ease(u / 0.7); f = ease((u - 0.72) / 0.28)
    arm = (0.95 + (2.6 - 0.95) * w - 2.2 * f, -0.25, 1.45 - 1.2 * w)
    scene_b(t, eo=0.9, hero_extra=dict(arm={'R': arm}, spine=-0.15 * w + 0.35 * f, twist=0.5 * w - 0.7 * f, head=(0.0, 0, 0), brow=(-0.25, 0)), phone=False)
    upd(); place_phone('phH', handp('hero') + V(0, 0, 0.03), normal=V(0, -1, 0.5)); ui('phH', 'rec4', 1, 0, t)
    campath((3.2, -0.6, 1.1), (3.0, -0.2, 1.0), (0, 0.7, 1.1), (0, 0.9, 1.0), u, 30, 32)


@shot(k0('coule'), k0('fond'))
def s25(t, u):
    scene_b(t, eo=0.9, hero_extra=dict(arm={'R': (0.4, -0.25, 0.3)}, head=(-0.1, 0, 0)), phone=False)
    a = V(-0.3, 1.0, 1.55); b = V(0.6, 6.0, -0.1)
    w = min(1, u / 0.78)
    pos = a.lerp(b, w) + V(0, 0, 1.6 * sin(pi * w))
    O['phH'].location = pos; O['phH'].rotation_euler = (t * 9, t * 5, 0); ui('phH', 'rec4', 1, 0, t)
    if u > 0.78:
        s = (u - 0.78) / 0.22; O['splash'].location = (0.6, 6.0, -0.1); O['splash'].scale = (1 + 4 * s, 1 + 4 * s, 1)
    campath((4.0, 2.0, 1.4), (3.5, 3.0, 1.2), (0.0, 1.8, 1.6), (0.6, 5.5, 0.2), u, 24, 26)


@shot(k0('fond'), k0('regarde'))
def s26(t, u):
    preset('uw')
    X = 200
    w = min(1, u / 0.45)
    O['phW'].location = (X, 1.0, 2.4 - 2.39 * ease(w)); O['phW'].rotation_euler = (0.3 * (1 - w), 0.2 * (1 - w), 0.3 + t * 0.3 * (1 - w))
    ui('phW', 'rec4', 0.35 if u < 0.62 else 1.3, 0, t)
    for i in range(14):
        ph = (t * 0.7 + i * 0.29) % 1
        O['bub%d' % i].location = (X + 0.3 * sin(i * 2.1), 1.0 + 0.3 * cos(i * 1.3), 0.2 + 2.5 * ph)
    eyes((X - 0.3, 4.5, 0.6), 1.5, 8 if u > 0.62 else 0)
    pp = O['phW'].location.copy()
    campath((X + 0.5, -0.6, 1.2), (X + 0.25, 0.35, 0.35), pp, pp, u, 30, 34)


@shot(k0('regarde'), k0('bus1'))
def s27(t, u):
    preset('dawn'); water(0.1, t)
    a = V(-0.2, 0.3, 0); b = V(-0.4, -3.6, 0)
    w = ease((u - 0.15) / 0.85); pos = a.lerp(b, w)
    ph = walkph((pos - a).length, 0.8)
    pose('hero', P(loc=pos + V(0.35, 0, 0), yaw=0, walk=ph, amp=0.4, arm={'R': (0.1, -0.25, 0.25)}, head=(0.1, 0.5 * (1 - u), 0), eo=0.85, brow=(0.3, 0)))
    pose('mami', P(loc=pos + V(-0.35, 0, 0), yaw=0, walk=ph + 1, amp=0.35, arm={'L': (0.1, 0.25, 0.25)}, spine=0.15, eo=0.9, brow=(-0.15, 0), mouth=E('M', t)))
    hh = headp('mami')
    cam(pos + V(0.2, -2.3, 1.35), pos + V(0, 0, 1.15), 32)


@shot(k0('bus1'), k0('bus1') + 1.4)
def s28(t, u):
    preset('road')
    X = 100
    a = V(X - 6, -3.8, 0); pos = a + V(2.2 * u, 0, 0)
    ph = walkph(2.2 * u, 0.8)
    pose('hero', P(loc=pos + V(0, 0.35, 0), yaw=pi / 2, walk=ph, amp=0.4, arm={'L': (0.1, -0.2, 0.25)}, eo=0.85, brow=(0.3, 0)))
    pose('mami', P(loc=pos + V(0, -0.35, 0), yaw=pi / 2, walk=ph + 1, amp=0.35, arm={'R': (0.1, -0.2, 0.25)}, spine=0.15, mouth=E('M', t), brow=(0.3, 0.01), eo=1.0))
    cam(pos + V(1.8, -1.6, 1.3), pos + V(0, 0, 1.2), 30)


@shot(k0('bus1') + 1.4, k0('six'))
def s29(t, u):
    preset('road')
    X = 100
    O['bus'].location = (X + 30 - 20 * ease(u), 0, 0)
    pose('hero', P(loc=(X - 2, -3.5, 0), yaw=pi / 2, head=(0, 0.2, 0), eo=0.9))
    pose('mami', P(loc=(X - 2.5, -3.9, 0), yaw=pi / 2, spine=0.15, eo=0.9))
    campath((X - 5, -4.8, 1.2), (X - 5, -4.6, 1.3), (X + 10, 0, 1.4), (X + 6, 0, 1.6), u, 30, 34)


@shot(k0('six'), k0('foret'))
def s30(t, u):
    preset('road')
    X = 100
    O['bus'].location = (X + 10 - 22 * u, 0, 0)
    campath((X - 2, -6.5, 1.0), (X - 3, -6.5, 1.1), (X + 6, 0, 1.6), (X - 10, 0, 1.6), u, 26, 26)


@shot(k0('foret'), k0('foret') + 0.8)
def s31(t, u):
    preset('busday')
    X = 300
    O['bi_trees'].location = (X - ((t * 9) % 4.2), 0, 0)
    pose('hero', P(loc=(X - 2.2, 0.85, -0.15), yaw=pi / 2, sit=1, head=(0.05, 0.9, 0), eo=0.8, brow=(0.3, 0)))
    pose('mami', P(loc=(X - 2.2, 0.35, -0.15), yaw=pi / 2, sit=1, head=(0.15, 0.3, 0), eo=0.6, spine=0.1))
    O['hero_hips'].location.z = 0.85; O['mami_hips'].location.z = 0.85
    campath((X - 0.55, 0.45, 1.45), (X - 0.65, 0.5, 1.42), (X - 2.2, 0.6, 0.95), (X - 2.2, 0.6, 0.95), u, 24, 26)


@shot(k0('foret') + 0.8, k0('main'))
def s32(t, u):
    preset('city')
    X = 400
    O['bus'].location = (X + 18 - 12 * u, 0.5, 0)
    campath((X - 20, 0, 9), (X - 16, 0, 8), (X + 6, 0.5, 1.5), (X + 4, 0.5, 1.5), u, 30, 32)


@shot(k0('main'), k0('etage'))
def s33(t, u):
    preset('city')
    X = 300
    O['bi_city'].location = (X - ((t * 7) % 3.2), 0, 0)
    pose('hero', P(loc=(X - 2.2, 0.85, -0.15), yaw=pi / 2, sit=1, head=(0.2, 0.6, 0), eo=0.7, brow=(0.3, 0),
                   arm={'R': (0.55, 0.05, 0.3)}))
    pose('mami', P(loc=(X - 2.2, 0.35, -0.15), yaw=pi / 2, sit=1, head=(0.25, -0.3, 0), eo=0.6, spine=0.1,
                   arm={'L': (0.75, -0.5, 0.45)}))
    O['bilamp'].data.energy = 12
    upd()
    hp = (handp('hero', 'R') + handp('mami', 'L')) / 2
    campath(hp + V(0.55, -0.6, 0.7), hp + V(0.45, -0.5, 0.6), hp, hp, u, 35, 38)


@shot(k0('etage'), k0('frappes'))
def s34(t, u):
    preset('indoor')
    X = 500
    tt = t - k0('etage')
    for nm, off, dy in (('hero', 0.0, 0.35), ('mami', -0.75, -0.35)):
        x = X - 3.3 + off + 1.1 * tt * 1.2 / 1.2
        z = max(0, min(1.8, (x - (X - 3.16)) / 0.32 * 0.18 + 0.18))
        pose(nm, P(loc=(x, dy, z), yaw=pi / 2, walk=walkph(x, 0.8), amp=0.5, spine=0.15, eo=0.85, brow=(0.3, 0)))
    campath((X - 4.2, -0.8, 0.7), (X - 4.0, -0.7, 0.9), (X - 2.0, 0, 1.6), (X - 1.0, 0.3, 2.4), u, 24, 26)


@shot(k0('frappes'), k0('porte'))
def s35(t, u):
    preset('indoor')
    X = 500
    tt = t - k1('frappes')
    kk = 0
    for i in range(3):
        d = tt - 0.15 - i * 0.32
        if 0 <= d < 0.3: kk = sin(d / 0.3 * pi)
    pose('hero', P(loc=(X + 2.95, 0.15, 1.8), yaw=pi / 2, arm={'R': (1.5, 0.05, 0.9 + 0.6 * kk)}, eo=0.9, brow=(0.3, 0), head=(0.05, 0, 0)))
    pose('mami', P(loc=(X + 2.2, -0.35, 1.8), yaw=pi / 2, spine=0.12, eo=0.8, brow=(0.3, 0)))
    campath((X + 2.2, -0.85, 3.25), (X + 2.35, -0.8, 3.2), (X + 3.2, 0.1, 2.9), (X + 3.2, 0.1, 2.85), u, 26, 28)


MAMAN0 = V(504.2, 0.0, 1.8)


def scene_door(t, door=1.0, hug=0.0, maman_extra=None, hero_extra=None):
    preset('indoor')
    O['doorh'].rotation_euler = (0, 0, -1.75 * door)
    mp = P(loc=MAMAN0 + V(-0.25 * hug, 0, 0), yaw=-pi / 2, eo=1.0, brow=(0.1, 0.0), arm={'L': (1.3 * hug, -0.5 * hug, 0.9 * hug), 'R': (1.3 * hug, -0.5 * hug, 0.9 * hug)}, spine=0.05)
    if maman_extra: mp.update(maman_extra)
    pose('maman', mp)
    hp = P(loc=(503.0 + 0.45 * hug, 0.15 - 0.15 * hug, 1.8), yaw=pi / 2, eo=1.0, brow=(0.2, 0), arm={'L': (0.9 * hug, -0.4 * hug, 0.8 * hug), 'R': (0.9 * hug, -0.4 * hug, 0.8 * hug)})
    if hero_extra: hp.update(hero_extra)
    pose('hero', hp)
    pose('mami', P(loc=(502.2, -0.35, 1.8), yaw=pi / 2, spine=0.12, eo=0.8, brow=(0.3, 0)))


@shot(k0('porte') - 0.15, k0('coeur'))
def s36(t, u):
    scene_door(t, ease(u * 1.6))
    campath((501.6, 0.45, 3.0), (501.9, 0.4, 3.0), (504.0, 0.0, 3.0), (504.0, 0.0, 3.2), u, 30, 34)


@shot(k0('coeur'), k0('serre'))
def s37(t, u):
    scene_door(t, 1, ease((u - 0.7) / 0.3) * 0.3, maman_extra=dict(mouth=E('MA', t), brow=(0.25, 0.02), eo=0.85))
    upd(); face_cam('maman', 1.15, 0.15, 0.0, 40, 0.2, u)


@shot(k0('serre'), k0('cheveux'))
def s38(t, u):
    scene_door(t, 1, 1.0, maman_extra=dict(eo=0.5, head=(0.15, 0.3, 0)), hero_extra=dict(head=(0, -0.3, 0)))
    a = 2.6 * u
    c = V(503.6, 0.05, 3.1)
    a = -0.7 + 1.0 * u
    cam(c + V(-1.4 * cos(a), 1.4 * sin(a), 0.2), c, 30)


def drops(t, base):
    for i in range(10):
        ph = (t * 1.3 + i * 0.137) % 1
        O['hdrop%d' % i].location = base + V(0.12 * sin(i * 2.3), 0.1 * cos(i * 1.7), -0.05 - 1.2 * ph * ph)


@shot(k0('cheveux'), k0('appart'))
def s39(t, u):
    scene_door(t, 1, 1.0, maman_extra=dict(eo=0.5, head=(0.15, 0.3, 0)), hero_extra=dict(head=(0, -0.3, 0)))
    upd(); h = headp('maman')
    drops(t, h + V(0.12, 0, 0.05))
    campath(h + V(0.55, -0.6, 0.1), h + V(0.45, -0.55, 0.05), h + V(0.12, 0, 0.0), h + V(0.12, 0, -0.15), u, 35, 38)


@shot(k0('appart'), k0('appart') + 1.0)
def s40(t, u):
    scene_door(t, 1, 1.0, maman_extra=dict(eo=0.5, head=(0.15, 0.3, 0)), hero_extra=dict(head=(0, -0.3, 0), eo=1.0 + 0.4 * ease(u), brow=(0.4, 0.03)))
    upd(); h = headp('hero'); drops(t, headp('maman') + V(0.12, 0, 0.05))
    cam(h + V(0.6, -0.55, 0.05), h + V(0, 0, 0.0), 45)


def phone_table(t, ring=1.0):
    j = 0.004 * sin(t * 90) * ring
    O['phW'].location = (506.4 + j, 1.4, 2.59); O['phW'].rotation_euler = (0, 0, 0.5 + j * 20)
    ui('phW', 'maman', 1.0, 0, t)


@shot(k0('appart') + 1.0, k0('ecran'))
def s41(t, u):
    scene_door(t, 1, 1.0)
    phone_table(t)
    campath((505.4, 0.5, 3.0), (505.6, 0.7, 2.9), (506.4, 1.4, 2.6), (506.4, 1.4, 2.6), u, 30, 36)


@shot(k0('ecran'), k0('decroche'))
def s42(t, u):
    scene_door(t, 1, 1.0)
    phone_table(t); upd()
    phone_cam('phW', 0.27, u, 0.3, 0.0, 38)


@shot(k0('decroche'), k0('quoi'))
def s43(t, u):
    scene_door(t, 1, 0.0, maman_extra=dict(loc=MAMAN0 + V(-0.6, 0, 0), mouth=E('MA', t), eo=0.95, brow=(0.35, 0.01), arm={'R': (0.6, -0.3, 0.9)}),
               hero_extra=dict(loc=(504.0, 0.6, 1.8), yaw=pi / 2 + 0.6))
    phone_table(t)
    upd(); face_cam('maman', 1.2, -0.15, 0.0, 40, 0.2, u)


def vote_scene(t):
    scene_door(t, 1, 0.0, maman_extra=dict(loc=V(504.8, -0.8, 1.8), eo=1.0, brow=(0.25, 0), yaw=2.7),
               hero_extra=dict(loc=(505.6, 0.9, 1.8), yaw=0.67, head=(0.05, 0.0, 0), eo=1.25, brow=(0.4, 0.03)))
    phone_table(t)


@shot(k0('quoi'), k0('un'))
def s44(t, u):
    vote_scene(t)
    campath((508.0, 0.3, 3.3), (507.6, 0.25, 3.25), (505.0, -0.1, 2.6), (505.0, -0.1, 2.6), u, 24, 26)


@shot(k0('un'), k0('deux'))
def s45(t, u):
    vote_scene(t); upd()
    face_cam('maman', 1.3, 0.2, -0.1, 40, 0.2, u, yawoff=0.0)


@shot(k0('deux'), k0('ecris'))
def s46(t, u):
    vote_scene(t); upd()
    phone_cam('phW', 0.3, u, 0.3, 0.0, 36)


@shot(k0('ecris'), TOTAL + 1)
def s47(t, u):
    vote_scene(t)
    campath((507.6, 0.25, 3.25), (507.2, 0.2, 3.2), (505.0, -0.1, 2.6), (505.1, 0.0, 2.6), u, 26, 30)


def apply(t):
    for a, b, f in SH:
        if a <= t < b:
            for nm in ('hero', 'mami', 'maman'):
                pose(nm, None)
            hide_misc()
            O['bilamp'].data.energy = 25
            f(t, (t - a) / max(1e-3, b - a))
            return f.__name__
    return None


def render(f0, f1, out='/kaggle/tmp/c/ep/fr', every=1, only=None):
    os.makedirs(out, exist_ok=True)
    sc = bpy.context.scene
    for f in range(f0, f1, every):
        t = f / 12.0
        if T_REW0 <= t < T_REW1:
            continue
        p = '%s/%05d.jpg' % (out, f)
        if os.path.exists(p) and only is None:
            continue
        sc.frame_set(f)
        name = apply(t)
        if name is None:
            continue
        sc.render.filepath = p
        bpy.ops.render.render(write_still=True)


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'keys':
        sc = bpy.context.scene; sc.cycles.samples = 6
        bpy.context.scene.cycles.samples = 6
        os.makedirs('/kaggle/tmp/c/ep/keys', exist_ok=True)
        sel = sys.argv[2].split(',') if len(sys.argv) > 2 else None
        for a, b, f in SH:
            if sel and f.__name__ not in sel:
                continue
            t = a + (b - a) * 0.6
            for nm in ('hero', 'mami', 'maman'): pose(nm, None)
            hide_misc(); O['bilamp'].data.energy = 25
            f(t, 0.6)
            sc.render.filepath = '/kaggle/tmp/c/ep/keys/%s.jpg' % f.__name__
            bpy.ops.render.render(write_still=True)
    else:
        bpy.context.scene.cycles.samples = 12
        render(int(sys.argv[2]), int(sys.argv[3]))
