import sys
src = open('/kaggle/tmp/c/ep/anim.py').read().split('# ------------------------------------------------------------- shared positions')[0]
src = src.replace('/kaggle/tmp/c/ep/', '/kaggle/tmp/c/tram/')
exec(src)
_a = open('/kaggle/tmp/c/ep/anim.py').read()
exec(_a[_a.index('def face_cam'):_a.index('# ------------------------------------------------------------- shots')])

X = 300
EXT = set()


def flick(t, base=1.0, bad=0.0):
    f = base
    if bad:
        n = sin(t * 37) * sin(t * 11.3) * sin(t * 5.1)
        if n > 0.55 - bad * 0.5: f *= 0.15
    bpy.data.materials['titube'].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value = 6 * f
    for i in range(4): O['til%d' % i].data.energy = 35 * f


def preset(name):
    w = bpy.data.worlds['W'].node_tree.nodes['Background']; sun = O['sun']
    if name == 'quay':
        w.inputs['Color'].default_value = (0.012, 0.016, 0.03, 1); sun.data.energy = 0.7; sun.data.color = (0.55, 0.65, 1.0)
        sun.rotation_euler = dirq((20, 60, -40)); O['camfill'].data.energy = 16; O['camfill'].data.color = (0.65, 0.75, 1.0)
    else:
        w.inputs['Color'].default_value = (0.0, 0.0, 0.0, 1); sun.data.energy = 0.0
        O['camfill'].data.energy = 9; O['camfill'].data.color = (0.85, 0.92, 1.0)


def ui(nm, state, on=1.0, wave=0.0, t=0.0):
    for k in ('rec4', 'rec5', 'wave', 'maman', 'batt'):
        for c in O['%s_%s' % (nm, k)].children:
            c.hide_render = (k != state)
    bpy.data.materials[nm + '_screen'].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value = 2.2 * on
    O[nm + '_glow'].data.energy = 0.3 * on


def ext_doors(o):
    for i, x in enumerate((-2.5, 2.5)):
        for s in (-1, 1):
            O['door%d%d' % (i, s)].location.x = x + s * (0.45 + 0.85 * o)


def int_doors(o):
    for s in (-1, 1):
        O['idoor%d' % s].location.x = X + 3 + s * (0.45 + 0.85 * o)


def led(term):
    O['ledA'].hide_render = term; O['ledB'].hide_render = not term


def smile(v):
    O['smile'].scale = (max(0.001, v), 1, max(0.001, v))


def hide_misc():
    O['tram'].location = (90, 3.1, 0); ext_doors(0); int_doors(0); led(False); smile(0)
    O['phH'].location = (0, 0, -60); O['phH_glow'].data.energy = 0
    flick(0)


def yaw_to(a, b): return math.atan2(b[0] - a[0], -(b[1] - a[1]))


HQ = V(0.0, 0.9, 0)
SEAT = V(X - 2.0, 0.78, -0.15)
DBL = V(X - 7.35, 0.35, -0.15)
SH = []
def shot(a, b, ext=False):
    def deco(f):
        SH.append((a, b, f))
        if ext: EXT.add(f.__name__)
        return f
    return deco


def hero_tel(t, eo=1.0, brow=(0.2, 0), head=(0.35, 0, 0)):
    pose('hero', P(loc=HQ, yaw=pi * 0.85, arm={'R': (0.35, -0.3, 1.35)}, head=head, eo=eo, brow=brow, spine=0.06))
    place_phone('phH', handp('hero') + V(0, 0, 0.04), look_at=headp('hero')); ui('phH', 'batt', 1)


@shot(0, k0('rater'), True)
def a1(t, u):
    preset('quay')
    pose('hero', P(loc=HQ, yaw=pi * 0.6, head=(0.05, 0.3, 0), eo=0.9, brow=(0.2, 0)))
    campath((-6, -4.5, 3.0), (-4.5, -3.6, 2.4), (0, 0.3, 2.2), (0, 0.4, 1.6), u, 26, 30)


@shot(k0('rater'), k0('tel'), True)
def a2(t, u):
    preset('quay')
    pose('hero', P(loc=HQ, yaw=pi * 0.6 - 0.5 * ease(u), head=(0.1, 0.5 - 0.6 * ease(u), 0), eo=0.85, brow=(0.3, 0)))
    face_cam('hero', 1.6, 0.4, 0.1, 35, 0.2, u)


@shot(k0('tel'), k0('pourtant'), True)
def a3(t, u):
    preset('quay'); hero_tel(t)
    phone_cam('phH', 0.3, u, 0.3, 0.02, 35)


@shot(k0('pourtant'), k0('ecrit'), True)
def b1(t, u):
    preset('quay')
    O['tram'].location = (70 - 40 * ease(u), 3.1, 0)
    pose('hero', P(loc=HQ, yaw=-pi / 2 + pi, head=(0, 0, 0), eo=1.1, brow=(0.3, 0.01)))
    campath((-1.5, 0.3, 1.0), (-1.4, 0.4, 1.0), (30, 3.1, 1.0), (25, 3.1, 1.2), u, 30, 35)


@shot(k0('ecrit'), k0('portes'), True)
def b2(t, u):
    preset('quay')
    O['tram'].location = (2.5 + 6 * (1 - ease(u * 1.2)), 3.1, 0)
    pose('hero', P(loc=HQ, yaw=pi / 2, eo=1.1, brow=(0.3, 0.01)))
    tf = O['tram'].location
    campath(tf + V(-9.5, -2.2, 2.5), tf + V(-9.2, -2.0, 2.6), tf + V(-7, 0, 2.8), tf + V(-7, 0, 2.9), u, 30, 34)


@shot(k0('portes'), k0('montes'), True)
def b3(t, u):
    preset('quay')
    O['tram'].location = (2.5, 3.1, 0); ext_doors(ease(u * 1.5))
    pose('hero', P(loc=HQ, yaw=pi, head=(0, 0, 0), eo=1.0, brow=(0.3, 0)))
    campath((0.6, -1.6, 1.5), (0.5, -1.3, 1.45), (0, 1.9, 1.2), (0, 1.9, 1.25), u, 28, 32)


@shot(k0('montes'), k0('interieur'), True)
def b4(t, u):
    preset('quay')
    O['tram'].location = (2.5, 3.1, 0); ext_doors(1)
    a = HQ; b = V(0, 2.4, 0.0)
    w = ease(u); pos = a.lerp(b, w)
    pose('hero', P(loc=pos, yaw=pi, walk=walkph((pos - a).length, 0.8), amp=0.4, eo=1.0))
    cam(V(-0.9, -1.2, 1.6), pos + V(0, 0.4, 1.0), 30)


@shot(k0('interieur'), k0('affiche'))
def c1(t, u):
    preset('tram'); flick(t, 1.0, 0.3)
    a = V(X + 3.0, -0.9, 0); b = V(X + 2.5, -0.05, 0)
    pos = a.lerp(b, ease(u))
    pose('hero', P(loc=pos, yaw=pi / 2 + 0.6 * (1 - u) + pi, walk=walkph((pos - a).length, 0.8), amp=0.3, head=(0, 0.5 * sin(u * 4), 0), eo=1.0, brow=(0.3, 0)))
    campath((X - 6.5, -0.3, 1.9), (X - 5.5, -0.2, 1.8), (X + 3, 0, 1.2), (X + 2.5, 0, 1.2), u, 24, 28)


def poster_cam(u, z0, z1, d0, d1, lens):
    p = O['poster'].location
    campath((p.x - 0.1, p.y - d0, p.z + z0), (p.x + 0.05, p.y - d1, p.z + z1), (p.x, p.y, p.z + z0), (p.x, p.y, p.z + z1), u, lens, lens + 3)


def hero_reading(t):
    pose('hero', P(loc=(X + 2.0, 0.25, 0), yaw=yaw_to((X + 2.0, 0.25), (X + 3.0, 1.25)), head=(-0.05, 0, 0), eo=1.0, brow=(0.3, 0)))


@shot(k0('affiche'), k0('r1'))
def c2(t, u):
    preset('tram'); flick(t); hero_reading(t)
    poster_cam(u, 0.15, 0.0, 2.3, 2.0, 30)


@shot(k0('r1'), k0('r2'))
def c3(t, u):
    preset('tram'); flick(t); hero_reading(t)
    poster_cam(u, 0.18, 0.12, 1.5, 1.3, 35)


@shot(k0('r2'), k0('r3'))
def c4(t, u):
    preset('tram'); flick(t); hero_reading(t)
    poster_cam(u, -0.12, -0.18, 1.5, 1.3, 35)


@shot(k0('r3'), k0('toujours'))
def c5(t, u):
    preset('tram'); flick(t); hero_reading(t)
    poster_cam(u, -0.45, -0.5, 1.5, 1.25, 35)


@shot(k0('toujours'), k0('assois'))
def c6(t, u):
    preset('tram'); flick(t, 1, 0.5); hero_reading(t)
    O['hero_root'].rotation_euler.z = pi
    pose('hero', P(loc=(X + 2.0, 0.25, 0), yaw=yaw_to((X + 2.0, 0.25), (X + 3.0, 1.25)), head=(0.0, 0, 0), eo=1.25, brow=(0.4, 0.02)))
    face_cam('hero', 1.0, 0.1, -0.05, 40, 0.25, u)


def dbl_sit(t, stand=0.0):
    w = ease(stand)
    pose('dbl', P(loc=DBL + V(0.2 * w, 0, 0.15 * w), yaw=pi / 2, sit=1 - w, spine=0.35 * (1 - w) + 0.1, head=(0.6 * (1 - w) + 0.3, 0, 0),
                  arm={'L': (0.5 * (1 - w), 0.1, 0.8 * (1 - w)), 'R': (0.5 * (1 - w), 0.1, 0.8 * (1 - w))}))


@shot(k0('assois'), k0('remarques'))
def d1(t, u):
    preset('tram'); flick(t); dbl_sit(t)
    w = ease(u * 1.3)
    a = V(X - 2.0, 0.1, 0)
    pose('hero', P(loc=a.lerp(SEAT, w), yaw=pi / 2, sit=w, eo=0.9, brow=(0.3, 0), head=(0.1, 0, 0)))
    campath((X + 0.3, -0.7, 1.6), (X + 0.1, -0.6, 1.55), (X - 2.0, 0.5, 0.9), (X - 2.0, 0.6, 0.85), u, 26, 28)


def hero_seated(look_back=0.0, eo=1.0, brow=(0.3, 0), mouth=0):
    pose('hero', P(loc=SEAT, yaw=pi / 2, sit=1, head=(0.05, -1.9 * look_back, 0), twist=-0.5 * look_back, eo=eo, brow=brow, mouth=mouth))


@shot(k0('remarques'), k0('assis'))
def d2(t, u):
    preset('tram'); flick(t, 1, 0.2); dbl_sit(t); hero_seated()
    campath((X - 1.0, 0.0, 1.5), (X - 4.6, 0.05, 1.25), (X - 7.3, 0.2, 0.9), (X - 7.3, 0.3, 0.8), u, 24, 30)


@shot(k0('assis'), k0('veste'))
def d3(t, u):
    preset('tram'); flick(t); dbl_sit(t); hero_seated(ease(u * 1.5), 1.1, (0.35, 0.01))
    h = headp('hero')
    cam(h + V(-0.95, -0.45, 0.05), h, 38)


@shot(k0('veste'), k0('veste') + 1.7)
def d4(t, u):
    preset('tram'); flick(t, 1, 0.3); dbl_sit(t); hero_seated(1)
    h = headp('dbl')
    campath(h + V(1.4, -0.7, -0.05), h + V(1.2, -0.6, -0.2), h + V(0, 0, -0.15), h + V(0, 0, -0.35), u, 32, 36)


@shot(k0('veste') + 1.7, k0('ctrl'))
def d5(t, u):
    preset('tram'); flick(t); dbl_sit(t); hero_seated(1, 1.0 + 0.45 * ease(u), (0.45, 0.03))
    h = headp('hero')
    cam(h + V(-0.9, -0.35, 0.0) * (1 - 0.2 * ease(u)), h, 40)


CT = V(X - 0.75, 0.05, 0)


def ctrl_pose(t, reach=0.0, turn=0.0, walk=None, loc=None, sm=0.0, head=(0.15, 0, 0)):
    yaw = yaw_to(CT, SEAT) + turn
    pose('ctrl', P(loc=loc or CT, yaw=yaw, walk=walk, amp=0.35, spine=0.08, head=head,
                   arm={'R': (1.35 * reach, -0.15 * reach, 0.25 * reach)}))
    smile(sm)


@shot(k0('ctrl'), k0('monter'))
def e1(t, u):
    preset('tram'); flick(t, 1, 0.8 if u < 0.3 else 0.0); dbl_sit(t); hero_seated(0.2, 1.3, (0.45, 0.03))
    ctrl_pose(t)
    h = headp('ctrl')
    campath(h + V(-1.7, -0.05, -1.0), h + V(-1.5, -0.05, -0.95), h + V(0, 0, -0.2), h + V(0, 0, -0.1), u, 24, 26)


@shot(k0('monter'), k0('tend'))
def e2(t, u):
    preset('tram'); flick(t); dbl_sit(t); hero_seated(0.15, 1.4, (0.5, 0.04))
    ctrl_pose(t)
    h = headp('hero')
    cam(h + V(0.85, -0.2, 0.0), h, 40)


@shot(k0('tend'), k0('ticket'))
def e3(t, u):
    preset('tram'); flick(t); dbl_sit(t); hero_seated(0.1, 1.3, (0.45, 0.03))
    ctrl_pose(t, ease(u * 1.4))
    h = headp('hero')
    campath(h + V(-0.55, 0.45, 0.25), h + V(-0.5, 0.4, 0.2), headp('ctrl') + V(0, 0, -0.3), headp('ctrl') + V(0, 0, -0.35), u, 30, 34)


@shot(k0('ticket'), k0('nerep'))
def e4(t, u):
    preset('tram'); flick(t, 0.8); dbl_sit(t); hero_seated(0.1, 1.3)
    ctrl_pose(t, 1.0, head=(0.25, 0, 0))
    face_cam('ctrl', 1.35, 0.1, -0.05, 38, 0.25, u)


@shot(k0('nerep'), k0('sourit'))
def e5(t, u):
    preset('tram'); flick(t); dbl_sit(t)
    pose('hero', P(loc=SEAT, yaw=pi / 2, sit=1, head=(0.35, 0.1, 0), eo=0.55, brow=(0.5, 0.0)))
    ctrl_pose(t, 1.0)
    face_cam('hero', 0.8, 0.12, -0.12, 42, 0.2, u)


@shot(k0('sourit'), k0('tourne'))
def e6(t, u):
    preset('tram'); flick(t, 0.8); dbl_sit(t); hero_seated(0.1, 1.2)
    ctrl_pose(t, 0.6 * (1 - u), sm=ease(u * 1.6), head=(0.2, 0, 0))
    face_cam('ctrl', 1.25, 0.05, 0.0, 38, 0.25, u)


@shot(k0('tourne'), k0('arrete'))
def e7(t, u):
    preset('tram'); flick(t); dbl_sit(t); hero_seated(0.6 * ease(u), 1.3, (0.45, 0.03))
    w = ease((u - 0.25) / 0.75)
    a = CT; b = V(X - 5.0, 0.0, 0)
    pos = a.lerp(b, w)
    turn = -yaw_to(CT, SEAT) + yaw_to(a, b)
    pose('ctrl', P(loc=pos, yaw=yaw_to(CT, SEAT) + turn * ease(u * 3), walk=walkph((pos - a).length, 1.06) if w > 0 else None, amp=0.3, spine=0.06))
    smile(1)
    campath((X + 0.8, -0.5, 1.5), (X + 0.6, -0.45, 1.5), (X - 1.5, 0, 1.4), (X - 4.5, 0, 1.3), u, 26, 28)


TCTRL = V(X - 5.4, 0.0, 0)


def ctrl_back():
    pose('ctrl', P(loc=TCTRL, yaw=yaw_to(TCTRL, DBL), spine=0.06)); smile(1)


@shot(k0('arrete'), k0('annonce'), True)
def f1(t, u):
    preset('quay')
    for nm in ('qll0', 'qll1', 'shl'): O[nm].data.energy = 0
    O['qlb0'].hide_render = O['qlb1'].hide_render = True
    O['tram'].location = (2.5 + 5 * (1 - ease(u)), 3.1, 0)
    campath((-14, -3, 1.2), (-13, -2.6, 1.3), (0, 3.1, 1.4), (1, 3.1, 1.4), u, 30, 32)


@shot(k0('annonce'), k0('descend'))
def f2(t, u):
    preset('tram'); flick(t, 1, 0.6); dbl_sit(t); hero_seated(0.0, 1.2); ctrl_back()
    led(t >= k0('terminus') - 0.1)
    campath((X + 3.1, 0.62, 1.98), (X + 3.0, 0.68, 2.0), (X + 3, 1.24, 2.14), (X + 3, 1.24, 2.14), u, 24, 26)


@shot(k0('descend'), k0('plan'))
def f3(t, u):
    preset('tram'); flick(t); dbl_sit(t); hero_seated(0.0, 1.2); ctrl_back(); led(True)
    int_doors(ease(u * 1.5))
    campath((X + 0.5, 0.7, 1.4), (X + 0.8, 0.6, 1.4), (X + 3, -1.3, 1.2), (X + 3, -1.3, 1.2), u, 28, 30)


@shot(k0('plan'), k0('quai'))
def f4(t, u):
    preset('tram'); flick(t); dbl_sit(t); hero_seated(0.0, 1.2); ctrl_back(); led(True); int_doors(1)
    p = O['linemap'].location
    campath(p + V(-0.4, 1.9, -0.4), p + V(0.3, 1.7, -0.35), p + V(-0.3, 0, 0), p + V(0.4, 0, 0), u, 24, 26)


@shot(k0('quai'), k0('derriere'))
def f5(t, u):
    preset('tram'); flick(t, 0.9, 0.3); dbl_sit(t); hero_seated(0.0, 1.2); ctrl_back(); led(True); int_doors(1)
    campath((X + 3, 0.9, 1.4), (X + 3, -0.6, 1.3), (X + 3, -3, 1.2), (X + 3, -3.5, 1.2), u, 28, 30)


@shot(k0('derriere'), k0('vingt'))
def f6(t, u):
    preset('tram'); flick(t, 1, 0.4); int_doors(1); led(True)
    dbl_sit(t, ease((u - 0.2) / 0.7)); hero_seated(0.0, 1.3, (0.45, 0.03)); ctrl_back()
    h = headp('hero')
    campath(h + V(0.6, -0.5, 0.15), h + V(0.5, -0.45, 0.1), headp('dbl'), headp('dbl') + V(0, 0, 0.1), u, 30, 34)


@shot(k0('vingt'), k0('choix'))
def g1(t, u):
    preset('tram'); flick(t, 1, 0.3); int_doors(1); led(True); dbl_sit(t, 1); ctrl_back()
    hero_seated(0.0, 1.4, (0.5, 0.04))
    face_cam('hero', 0.95, -0.15, -0.05, 40, 0.2, u)


@shot(k0('choix'), TOTAL + 1)
def g2(t, u):
    preset('tram'); flick(t, 1, 0.3); int_doors(1); led(True); dbl_sit(t, 1); ctrl_back()
    pose('hero', P(loc=(X + 2.2, 0.1, 0), yaw=pi * 0.8, head=(0, 0.6 * sin(t * 1.3), 0), eo=1.35, brow=(0.5, 0.04)))
    pose('dbl', P(loc=DBL + V(2.0 * ease(u), 0, 0), yaw=pi / 2, walk=walkph(2.0 * ease(u), 0.8), amp=0.3, head=(0.35, 0, 0)))
    campath((X + 4.9, 0.3, 1.6), (X + 4.5, 0.25, 1.55), (X + 1.5, -0.3, 1.1), (X + 1.5, -0.3, 1.1), u, 22, 24)


def apply(t):
    for a, b, f in SH:
        if a <= t < b:
            for nm in ('hero', 'dbl', 'ctrl'): pose(nm, None)
            hide_misc()
            for nm in ('qll0', 'qll1'): O[nm].data.energy = 120
            O['shl'].data.energy = 35; O['qlb0'].hide_render = O['qlb1'].hide_render = False
            f(t, (t - a) / max(1e-3, b - a))
            return f.__name__
    return None


def render(f0, f1, out='/kaggle/tmp/c/tram/fr'):
    os.makedirs(out, exist_ok=True)
    sc = bpy.context.scene
    for f in range(f0, f1):
        p = '%s/%05d.jpg' % (out, f)
        if os.path.exists(p): continue
        t = f / 12.0
        if apply(t) is None: continue
        sc.render.filepath = p; bpy.ops.render.render(write_still=True)


if __name__ == '__main__':
    mode = sys.argv[1]
    sc = bpy.context.scene
    if mode == 'keys':
        sc.cycles.samples = 6
        os.makedirs('/kaggle/tmp/c/tram/keys', exist_ok=True)
        sel = sys.argv[2].split(',') if len(sys.argv) > 2 else None
        for a, b, f in SH:
            if sel and f.__name__ not in sel: continue
            t = a + (b - a) * 0.6
            apply(t)
            sc.render.filepath = '/kaggle/tmp/c/tram/keys/%s.jpg' % f.__name__
            bpy.ops.render.render(write_still=True)
    else:
        sc.cycles.samples = 8; sc.cycles.diffuse_bounces = 1; sc.cycles.glossy_bounces = 1
        render(int(sys.argv[2]), int(sys.argv[3]))
