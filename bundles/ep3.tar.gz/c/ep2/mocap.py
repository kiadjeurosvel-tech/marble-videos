import numpy as np, math, os, pickle

NEED = ['Hips', 'LeftUpLeg', 'LeftLeg', 'LeftFoot', 'RightUpLeg', 'RightLeg', 'RightFoot', 'LowerBack', 'Neck', 'Head',
        'LeftArm', 'LeftForeArm', 'LeftHand', 'RightArm', 'RightForeArm', 'RightHand']


def rot(axis, a):
    c, s = math.cos(a), math.sin(a)
    if axis == 'X': return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    if axis == 'Y': return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def parse(path):
    lines = open(path).read().split('\n')
    joints = []; stack = []; i = 0
    while not lines[i].strip().startswith('MOTION'):
        tok = lines[i].split()
        if tok and tok[0] in ('ROOT', 'JOINT', 'End'):
            name = tok[1] if tok[0] != 'End' else (stack[-1] + '_end')
            joints.append(dict(name=name, parent=stack[-1] if stack else None, offset=None, ch=[], end=tok[0] == 'End'))
            stack.append(name)
        elif tok and tok[0] == 'OFFSET':
            joints[-1 if joints[-1]['offset'] is None else -1]['offset'] = np.array(list(map(float, tok[1:4])))
            # find the most recent joint without offset
        elif tok and tok[0] == 'CHANNELS':
            joints[-1]['ch'] = tok[2:]
        elif tok and tok[0] == '}':
            stack.pop()
        i += 1
    n = int(lines[i + 1].split()[1]); ft = float(lines[i + 2].split()[2])
    data = np.array([list(map(float, l.split())) for l in lines[i + 3:i + 3 + n]])
    return joints, ft, data


def fk(path):
    cache = path + '.pkl'
    if os.path.exists(cache):
        return pickle.load(open(cache, 'rb'))
    joints, ft, data = parse(path)
    idx = {}; c = 0
    for j in joints:
        idx[j['name']] = c; c += len(j['ch'])
    byname = {j['name']: j for j in joints}
    n = len(data); P = {k: np.zeros((n, 3)) for k in NEED}
    for f in range(n):
        W = {}
        for j in joints:
            if j['end']: continue
            ch = j['ch']; v = data[f, idx[j['name']]:idx[j['name']] + len(ch)]
            R = np.eye(3); t = j['offset'].copy()
            for cn, val in zip(ch, v):
                if cn.endswith('position'):
                    t = np.array([v[ch.index('Xposition')], v[ch.index('Yposition')], v[ch.index('Zposition')]])
                else:
                    R = R @ rot(cn[0], math.radians(val))
            if j['parent'] is None:
                W[j['name']] = (R, t)
            else:
                PR, Pt = W[j['parent']]
                W[j['name']] = (PR @ R, Pt + PR @ j['offset'])
            if j['name'] in P:
                P[j['name']][f] = W[j['name']][1]
    # BVH Y-up -> Blender Z-up
    for k in P:
        p = P[k]; P[k] = np.stack([p[:, 0], -p[:, 2], p[:, 1]], 1)
    res = dict(P=P, fps=1 / ft, n=n)
    pickle.dump(res, open(cache, 'wb'))
    return res


if __name__ == '__main__':
    import sys
    for f in sys.argv[1:]:
        r = fk(f); P = r['P']; fps = r['fps']
        hz = P['Hips'][:, 2]; leg = np.linalg.norm(P['LeftUpLeg'][0] - P['LeftLeg'][0]) + np.linalg.norm(P['LeftLeg'][0] - P['LeftFoot'][0])
        print(os.path.basename(f), 'fps', round(fps), 'dur', round(r['n'] / fps, 1), 'leg', round(leg, 2))
        for s in np.arange(0, r['n'] / fps, 1.0):
            i = int(s * fps)
            rh = P['RightHand'][i] - P['Hips'][i]; lh = P['LeftHand'][i] - P['Hips'][i]
            print('  t%4.1f hipz %.2f  Rhand(%.1f %.1f %.1f) Lhand(%.1f %.1f %.1f) hipxy(%.1f %.1f)' % (s, hz[i] / leg, *(rh / leg), *(lh / leg), *(P['Hips'][i][:2] / leg)))
