import sys, os, math
sys.path.insert(0, '/kaggle/tmp/c/ep2')
_t = open('/kaggle/tmp/c/tram/tanim.py').read().replace('/kaggle/tmp/c/tram/', '/kaggle/tmp/c/ep2/')
exec(_t[:_t.index("@shot(0, k0('rater'), True)")])
from mathutils import Quaternion, Matrix
import mocap as MC

CL = {k: MC.fk('/kaggle/tmp/c/mocap/%s.bvh' % k) for k in ('07_04', '13_01', '18_01', '18_03', '19_03')}
PIV = ['spine', 'head', 'shL', 'elL', 'shR', 'elR', 'hipL', 'knL', 'hipR', 'knR']
ZP, ZN = Vector((0, 0, 1)), Vector((0, 0, -1))


def pose2(nm, p):
    for k in PIV:
        O['%s_%s' % (nm, k)].rotation_mode = 'XYZ'
    pose(nm, p)


def mo(nm, clip, tc, skip=(), head_yaw=0.0, head_pitch=0.0, hz_scale=1.0):
    r = CL[clip]; P = r['P']; i = max(0, min(r['n'] - 1, int(tc * r['fps'])))
    g = lambda j: Vector(P[j][i])
    v = g('LeftUpLeg') - g('RightUpLeg'); v.z = 0
    f = v.cross(ZP).normalized(); yaw = math.atan2(f.x, -f.y)
    Ri = Matrix.Rotation(-yaw, 3, 'Z')
    d = lambda a, b: (Ri @ (g(b) - g(a))).normalized()
    leg = (P['LeftUpLeg'][0] - P['LeftLeg'][0]); import numpy as np
    L = np.linalg.norm(P['LeftUpLeg'][0] - P['LeftLeg'][0]) + np.linalg.norm(P['LeftLeg'][0] - P['LeftFoot'][0])
    hz = P['Hips'][i][2] / L
    O[nm + '_hips'].location.z = 0.85 * (1 + (hz / 1.19 - 1) * hz_scale)
    qs = ZP.rotation_difference(d('Hips', 'Neck'))
    qh = ZP.rotation_difference(qs.inverted() @ d('Neck', 'Head'))
    qh = qh @ Quaternion((0, 0, 1), head_yaw) @ Quaternion((1, 0, 0), head_pitch)
    Q = {'spine': qs, 'head': qh}
    for s, side in (('L', 'Left'), ('R', 'Right')):
        q1 = ZN.rotation_difference(qs.inverted() @ d(side + 'Arm', side + 'ForeArm'))
        q2 = ZN.rotation_difference((qs @ q1).inverted() @ d(side + 'ForeArm', side + 'Hand'))
        q3 = ZN.rotation_difference(d(side + 'UpLeg', side + 'Leg'))
        q4 = ZN.rotation_difference(q3.inverted() @ d(side + 'Leg', side + 'Foot'))
        Q['sh' + s], Q['el' + s], Q['hip' + s], Q['kn' + s] = q1, q2, q3, q4
    for k, q in Q.items():
        if k in skip: continue
        o = O['%s_%s' % (nm, k)]; o.rotation_mode = 'QUATERNION'; o.rotation_quaternion = q


def face(nm, eo=1.0, brow=(0.3, 0), mouth=0.0):
    for sg in (1, -1):
        O['%s_eye%d' % (nm, sg)].scale = (1, 1, max(0.08, eo))
        b = O['%s_brow%d' % (nm, sg)]; b.rotation_euler = (0, brow[0] * sg, 0); b.location.z = 0.315 + brow[1]
    O[nm + '_mouth'].scale = (1 - 0.25 * mouth, 1, 1 + 3.2 * mouth)


def place(nm, loc, yaw, lie=0):
    O[nm + '_root'].location = loc; O[nm + '_root'].rotation_euler = (lie, 0, yaw)


def walkclip(nm, loc, yaw, tc, **kw):
    pose2(nm, P(loc=loc, yaw=yaw)); mo(nm, '07_04', 0.6 + tc, **kw)


SEATH = V(X - 2.0, 1.0, -0.05)
SEATD = V(X - 2.0, 0.48, -0.05)


def hero_sit(eo=1.0, brow=(0.3, 0), head=(0.05, 0, 0), mouth=0, arm=None):
    p = P(loc=SEATH, yaw=pi / 2, sit=1, head=head, eo=eo, brow=brow, mouth=mouth)
    if arm: p['arm'] = arm
    pose2('hero', p)


def dbl_back(stand=0.0):
    w = ease(stand)
    pose2('dbl', P(loc=DBL + V(0.2 * w, 0, 0.15 * w), yaw=pi / 2, sit=1 - w, spine=0.35 * (1 - w) + 0.1, head=(0.6 * (1 - w) + 0.3, 0, 0),
                   arm={'L': (0.5 * (1 - w), 0.1, 0.8 * (1 - w)), 'R': (0.5 * (1 - w), 0.1, 0.8 * (1 - w))}))


CTA = V(X - 1.2, -0.35, 0)


def ctrl_at(loc, yaw, lean=0.0, reach=0.0, sm=1.0, head=(0.15, 0, 0)):
    pose2('ctrl', P(loc=loc, yaw=yaw, spine=0.08 + lean, head=head, arm={'R': (1.35 * reach, -0.15 * reach, 0.25 * reach)}))
    smile(sm)


def neons(n_off, red=0.0):
    for i in range(4):
        on = 0.0 if i >= 4 - n_off else 1.0
        O['til%d' % i].data.energy = 35 * on
        O['tit%d' % i].hide_render = on == 0
    O['emerg'].data.energy = 60 * red


SH = []
REW0, REW1 = 23.7, k0('descendu') - 0.05
DEATH0 = 22.35


def shot(a, b, ext=False):
    def deco(f):
        SH.append((a, b, f))
        if ext: EXT.add(f.__name__)
        return f
    return deco


# --------------------------------------------------------------- vote + death branch
@shot(0, k0('sireste'))
def v0(t, u):
    preset('tram'); flick(t, 1, 0.2); int_doors(1); led(True)
    pose2('hero', P(loc=(X + 2.6, -0.4, 0), yaw=-pi * 0.05, eo=1.2, brow=(0.4, 0.02)))
    campath((X + 2.7, 1.0, 1.5), (X + 2.85, 0.6, 1.45), (X + 3.0, -2.5, 1.2), (X + 3.0, -3.0, 1.1), u, 24, 28)


@shot(k0('sireste'), k0('repart'))
def d1(t, u):
    preset('tram'); flick(t); int_doors(1 - ease(u)); led(True); dbl_back()
    hero_sit(1.15, (0.4, 0.02))
    h = headp('hero')
    campath(h + V(1.3, -0.45, 0.0), h + V(0.9, -0.3, 0.0), h, h, u, 38, 42)


@shot(k0('repart'), k0('leve'), True)
def d2(t, u):
    preset('quay')
    for nm in ('qll0', 'qll1', 'shl'): O[nm].data.energy = 0
    O['qlb0'].hide_render = O['qlb1'].hide_render = True
    O['tram'].location = (2.5 - 9 * ease(u) ** 1.5, 3.1, 0)
    campath((10, -2.6, 1.0), (9, -2.4, 1.1), (0, 3.1, 1.5), (-4, 3.1, 1.5), u, 28, 30)


@shot(k0('leve'), k0('leve') + 1.3)
def d3(t, u):
    preset('tram'); flick(t); hero_sit()
    pose2('dbl', P(loc=DBL + V(0, 0, -0.05), yaw=pi / 2)); mo('dbl', '13_01', 7.8 + 1.6 * u, head_pitch=0.35)
    h = headp('hero')
    cam(h + V(0.35, -0.55, 0.12), DBL + V(0, 0, 0.9), 30)


@shot(k0('leve') + 1.3, k0('cote'))
def d4(t, u):
    preset('tram'); flick(t, 1, 0.15); hero_sit(1.2, (0.45, 0.03), head=(0.0, -1.6, 0))
    a = V(X - 7.0, 0.1, 0); b = V(X - 2.4, 0.05, 0)
    pos = a.lerp(b, u)
    walkclip('dbl', pos, pi / 2, (t - k0('leve') - 1.3), head_pitch=0.45)
    campath((X - 1.4, -0.2, 1.1), (X - 1.5, -0.15, 1.05), pos + V(0, 0, 0.9), pos + V(0, 0, 0.9), u, 26, 30)


@shot(k0('cote'), k0('penche'))
def d5(t, u):
    preset('tram'); flick(t); hero_sit(1.3, (0.45, 0.03), head=(0.0, -0.6, 0))
    w = min(1, u * 1.2)
    pose2('dbl', P(loc=SEATD.lerp(V(X - 2.35, 0.3, 0), 1 - w) + V(0, 0, -0.03), yaw=pi / 2))
    mo('dbl', '13_01', 3.0 + 2.0 * w, head_pitch=0.5, hz_scale=1.6)
    campath((X - 0.4, 0.75, 1.25), (X - 0.55, 0.72, 1.2), (X - 2.0, 0.75, 0.95), (X - 2.0, 0.75, 0.9), u, 26, 30)


def seated_pair(t, hero_kw=None):
    hk = dict(eo=1.35, brow=(0.5, 0.04), head=(0.0, -0.5, 0)); hk.update(hero_kw or {})
    hero_sit(**hk)
    pose2('dbl', P(loc=SEATD, yaw=pi / 2)); mo('dbl', '13_01', 6.0 + 0.3 * sin(t), head_pitch=0.5, hz_scale=1.6)


@shot(k0('penche'), k0('prise'))
def d6(t, u):
    preset('tram'); flick(t, 0.9); seated_pair(t)
    ctrl_at(CTA, yaw_to(CTA, SEATH), lean=0.45 * ease(u), sm=0.0)
    h = headp('ctrl')
    campath(h + V(-1.6, -0.8, -1.0), h + V(-1.4, -0.7, -0.95), h + V(0, 0, -0.2), h + V(0, 0, -0.1), u, 24, 26)


@shot(k0('prise'), k0('main'))
def d7(t, u):
    preset('tram'); flick(t, 0.8); seated_pair(t)
    ctrl_at(CTA, yaw_to(CTA, SEATH), lean=0.45, sm=ease(u * 2), head=(0.25, 0, 0))
    face_cam('ctrl', 1.1, 0.0, -0.05, 38, 0.3, u)


@shot(k0('main'), k0('neons'))
def d8(t, u):
    preset('tram'); flick(t, 0.8)
    w = ease(u * 1.6)
    seated_pair(t)
    pose2('dbl', P(loc=SEATD, yaw=pi / 2, sit=1, head=(0.5, -0.3, 0), arm={'L': (0.7 + 0.4 * w, -0.9 * w, 0.4)}))
    O['dbl_hips'].location.z = 0.85
    ctrl_at(CTA, yaw_to(CTA, SEATH), lean=0.45, sm=1)
    h = handp('hero', 'R')
    campath(h + V(0.45, -0.55, 0.3), h + V(0.35, -0.45, 0.22), h, h, u, 32, 36)


@shot(k0('neons'), k0('tire'))
def d9(t, u):
    preset('tram'); seated_pair(t, dict(eo=1.45))
    ctrl_at(CTA, yaw_to(CTA, SEATH), lean=0.3, sm=1)
    n = min(4, int(u * 5)); neons(n, red=ease((u - 0.6) / 0.4))
    for i in range(16):
        k = i // 4; t0 = k / 5
        s = (u - t0) * 2.0
        if 0 <= s < 1 and k < 4:
            a = i * 1.7
            O['spark%d' % i].location = (X - 6 + (3 - k) * 4 + sin(a) * s * 0.8, cos(a) * s * 0.5, 2.3 - 2.0 * s * s)
    campath((X + 1.0, 0.0, 1.0), (X + 0.6, 0.0, 1.0), (X - 4, 0, 2.3), (X - 4, 0, 2.2), u, 22, 24)


@shot(k0('tire'), DEATH0)
def d10(t, u):
    preset('tram'); neons(4, red=1.0); O['camfill'].data.energy = 2; O['camfill'].data.color = (1, 0.2, 0.15)
    tc = 1.0 + 2.6 * u
    pos = SEATH.lerp(V(X - 5.5, 0.1, 0), ease(u))
    pose2('hero', P(loc=pos, yaw=-pi / 2, eo=1.45, brow=(0.5, 0.04), mouth=0.8)); mo('hero', '19_03', tc)
    face('hero', 1.45, (0.5, 0.04), 0.8)
    pose2('dbl', P(loc=pos + V(-0.9, 0, 0), yaw=pi / 2)); mo('dbl', '18_03', tc, head_pitch=0.3)
    pose2('ctrl', None)
    campath((X - 1.0, -0.9, 1.3), (X - 1.6, -0.8, 1.25), pos + V(-0.4, 0, 0.9), pos + V(-0.5, 0, 0.9), u, 24, 26, shake=0.03, t=t)


@shot(DEATH0, REW0)
def dd(t, u):
    preset('tram'); neons(4); O['camfill'].data.energy = 0; O['sun'].data.energy = 0
    for i in range(4): O['til%d' % i].data.energy = 0
    XS = 700
    hit = 0.42
    w = ease(u / hit)
    pose2('dbl', P(loc=(XS - 0.95, 0.6, 0), yaw=pi / 2 + 0.2, spine=0.15 + 0.3 * (1 if u > hit else w),
                   arm={'R': (2.9 - 2.2 * (0 if u < hit else ease((u - hit) / 0.12)), 0.1, 0.4), 'L': (1.4, -0.3, 0.6)}))
    fall = ease((u - hit) / 0.3)
    pose2('hero', P(loc=(XS - 0.25, 0.7, 0.0), yaw=-pi / 2 + 0.2, lie=0.0, spine=-0.3 - 0.9 * fall, head=(-0.4 - 0.5 * fall, 0, 0),
                    arm={'L': (1.0 + 1.2 * fall, 0.6, 0.3), 'R': (1.6, 0.4, 0.4)}, leg={'L': (0.3 * fall, 0.5 * fall), 'R': (0.5 * fall, 0.8 * fall)}))
    O['hero_root'].location.z = -0.35 * fall
    if u > hit:
        s = (u - hit) / (1 - hit)
        for i in range(24):
            a = i * 2.39; sp = 0.6 + (i % 5) * 0.25
            O['bdrop%d' % i].location = (XS - 0.45 + cos(a) * sp * s * 1.4, 0.55 - sp * s * 1.2 * (0.5 + 0.5 * abs(sin(a))), 1.35 + sin(a) * sp * s - 2.5 * s * s)
        for i in range(18):
            o = O['splat%d' % i]; o.hide_render = s < (i % 6) * 0.06
    O['silseat'].hide_render = O['silseatb'].hide_render = True
    shake = 0.05 if hit < u < hit + 0.2 else 0.0
    cam((XS - 0.5, -3.4, 0.75), (XS - 0.5, 0.5, 1.05), 30, shake=shake, t=t * 3)


# --------------------------------------------------------------- survival branch
HQ2 = V(0.0, 0.9, 0)


def quay_dark():
    preset('quay')
    for nm in ('qll0', 'qll1', 'shl'): O[nm].data.energy = 0
    O['qlb0'].hide_render = O['qlb1'].hide_render = True
    O['signt'].hide_render = True
    O['camfill'].data.energy = 16
    O['shl'].data.energy = 9 * (0.4 + 0.6 * (math.sin(bpy.context.scene.frame_current * 1.7) > -0.7))


@shot(REW1, k0('referment'), True)
def s1(t, u):
    quay_dark(); O['tram'].location = (2.5, 3.1, 0); ext_doors(1)
    a = V(-0.05, 2.5, 0); b = V(-0.1, 0.9, 0); pos = a.lerp(b, ease(u))
    walkclip('hero', pos, 0.0, t - REW1)
    face('hero', 1.1, (0.35, 0.01))
    campath((0.7, -1.4, 1.2), (0.6, -1.2, 1.15), pos + V(0, 0, 1.0), pos + V(0, 0, 1.0), u, 28, 30)


@shot(k0('referment'), k0('quai'), True)
def s2(t, u):
    quay_dark(); O['tram'].location = (2.5, 3.1, 0); ext_doors(1 - ease(u * 1.3))
    pose2('hero', P(loc=HQ2, yaw=pi, head=(0, 0.2, 0), eo=1.1, brow=(0.35, 0.01)))
    campath((1.6, -0.9, 1.2), (1.4, -0.8, 1.2), (0, 1.8, 1.3), (-0.2, 1.8, 1.3), u, 28, 30)


@shot(k0('quai'), k0('poche'), True)
def s3(t, u):
    quay_dark(); O['tram'].location = (2.5 - 25 * ease(u) ** 1.6, 3.1, 0)
    pose2('hero', P(loc=HQ2, yaw=pi, head=(0, -0.4 * u, 0), eo=1.0, brow=(0.35, 0.01)))
    campath((3.5, -5, 3.0), (3.0, -4.6, 2.6), (0, 0.9, 0.8), (0, 0.9, 0.9), u, 26, 28)


def ticket_in_hand(flip=0.0, side=(0, 0)):
    h = handp('hero', 'R'); hd = headp('hero')
    n = (hd - h).normalized()
    O['ticket'].location = h + n * 0.08 + V(0, 0, 0.03)
    q = n.to_track_quat('Z', 'Y'); O['ticket'].rotation_mode = 'QUATERNION'
    O['ticket'].rotation_quaternion = q @ Quaternion((0, 1, 0), pi * flip)


HOLD = {'R': (0.35, -0.3, 1.35)}


@shot(k0('poche'), k0('ticket'), True)
def s4(t, u):
    quay_dark()
    w = ease(u * 1.3)
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1, head=(0.15, 0, 0), eo=0.9, brow=(0.35, 0),
                    arm={'R': (0.05 + 0.3 * w, 0.25 - 0.55 * w, 0.3 + 1.05 * w)}))
    if u > 0.55: ticket_in_hand()
    h = headp('hero')
    campath(h + V(0.6, -1.1, -0.3), h + V(0.45, -0.9, -0.35), h + V(0, 0, -0.45), h + V(0, 0, -0.35), u, 32, 36)


def ticket_cam(u, dist=0.22):
    upd(); o = O['ticket']; m = o.matrix_world
    n = (m.to_3x3() @ Vector((0, 0, 1))).normalized(); upv = (m.to_3x3() @ Vector((0, 1, 0))).normalized()
    d = dist * (1 - 0.2 * ease(u)); pos = m.translation + n * d
    c = O['cam']; c.location = pos; c.data.lens = 40
    mm = Matrix.Identity(3); zc = (pos - m.translation).normalized(); yc = (upv - zc * upv.dot(zc)).normalized()
    mm.col[0] = yc.cross(zc); mm.col[1] = yc; mm.col[2] = zc; c.rotation_euler = mm.to_euler()


@shot(k0('ticket'), k0('dos'), True)
def s5(t, u):
    quay_dark()
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1, head=(0.35, 0, 0), arm=HOLD)); ticket_in_hand()
    ticket_cam(u, 0.3)


@shot(k0('dos'), k0('ctrl'), True)
def s6(t, u):
    quay_dark()
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1, head=(0.35, 0, 0), arm=HOLD)); ticket_in_hand(ease((u - 0.1) / 0.4))
    upd(); o = O['ticket']; m = o.matrix_world.translation
    hd = headp('hero'); n = (hd - m).normalized()
    pos = m + n * 0.3 * (1 - 0.15 * u)
    cam(pos, m, 40)


CTQ = V(-2.6, -1.8, 0)


@shot(k0('ctrl'), k0('vu'), True)
def s7(t, u):
    quay_dark(); O['qlb0'].hide_render = False; O['qll0'].data.energy = 25 * (0.5 + 0.5 * (sin(t * 23) > -0.6))
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1, head=(0.35, 0, 0), arm=HOLD)); ticket_in_hand(1)
    ctrl_at(CTQ, yaw_to(CTQ, HQ2), sm=0)
    campath((1.6, 2.2, 1.2), (1.3, 1.9, 1.2), (-2.6, -1.8, 1.4), (-2.4, -1.6, 1.4), u, 30, 34)


@shot(k0('vu'), k0('tend'), True)
def s8(t, u):
    quay_dark()
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1 - 2.2 * ease(u * 2), head=(0.05, 0, 0), arm=HOLD, eo=1.45, brow=(0.5, 0.04)))
    ticket_in_hand(1)
    ctrl_at(CTQ, yaw_to(CTQ, HQ2), sm=0)
    face_cam('hero', 0.95, 0.1, -0.05, 40, 0.2, u)


def facing(t):
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2), head=(0.05, 0, 0), arm=HOLD, eo=1.4, brow=(0.5, 0.04)))
    ticket_in_hand(1)


CTQ2 = V(-1.0, -0.5, 0)


@shot(k0('tend'), k0('vingt'), True)
def s9(t, u):
    quay_dark(); facing(t)
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2))); mo('ctrl', '18_01', 1.2 + 1.2 * u, head_pitch=0.2); smile(ease((u - 0.4) / 0.4))
    h = headp('ctrl')
    campath(h + V(-0.4, -1.4, -0.9), h + V(-0.35, -1.2, -0.85), h + V(0.3, 0.4, -0.4), h + V(0.3, 0.4, -0.35), u, 26, 28)


@shot(k0('vingt'), k0('un'), True)
def s10(t, u):
    quay_dark(); facing(t)
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2))); mo('ctrl', '18_01', 2.4, head_pitch=0.2); smile(1)
    face_cam('hero', 1.0, -0.15, -0.05, 40, 0.2, u)


@shot(k0('un'), k0('peutetre'), True)
def c1(t, u):
    quay_dark()
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2))); mo('ctrl', '18_01', 2.4, head_pitch=0.25); smile(1)
    upd(); hc = handp('ctrl', 'R')
    O['ticket'].location = hc + V(0, 0, 0.05); O['ticket'].rotation_mode = 'XYZ'; O['ticket'].rotation_euler = (0.3, 0, 0.6)
    O['tkhole'].hide_render = u < 0.45
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2), eo=1.3, brow=(0.45, 0.03), arm={'R': (0.9 * (1 - ease(u * 2)), -0.2, 0.3)}))
    if u < 0.5:
        campath(hc + V(0.35, -0.45, 0.25), hc + V(0.3, -0.4, 0.2), hc, hc, u * 2, 35, 38)
    else:
        O['tram'].location = (2.5, 3.1, 0); ext_doors(ease((u - 0.5) / 0.4))
        O['tin'].data.energy = 800
        campath((0.9, -1.5, 1.4), (0.8, -1.2, 1.4), (0, 2.2, 1.2), (0, 2.2, 1.2), (u - 0.5) * 2, 26, 28)


@shot(k0('peutetre'), k0('deux'), True)
def c2(t, u):
    quay_dark(); O['tram'].location = (2.5, 3.1, 0); ext_doors(1); O['tin'].data.energy = 800
    a = HQ2; b = V(-0.05, 1.7, 0); pos = a.lerp(b, ease(u * 0.8))
    walkclip('hero', pos, pi, (t - k0('peutetre')) * 0.7)
    face('hero', 1.0, (0.3, 0))
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, pos))); smile(1)
    campath((-0.3, -2.6, 1.5), (-0.2, -2.0, 1.45), (0, 2.2, 1.3), (0, 2.4, 1.3), u, 26, 30)


@shot(k0('deux'), k0('personne'), True)
def c3(t, u):
    quay_dark(); O['tkhole'].hide_render = True
    w = ease((u - 0.25) / 0.35)
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1, head=(0.4, 0, 0), eo=1.2, brow=(-0.2, 0.0),
                    arm={'R': (0.45, -0.25 + 0.25 * w, 1.3), 'L': (0.45, -0.3 + 0.25 * w, 1.3)}))
    upd(); hR = handp('hero', 'R'); hL = handp('hero', 'L'); mid = (hR + hL) / 2; hd = headp('hero')
    n = (hd - mid).normalized(); q = n.to_track_quat('Z', 'Y').to_euler()
    O['ticket'].location = mid; O['ticket'].rotation_mode = 'XYZ'; O['ticket'].rotation_euler = q
    O['tkL'].location = (-0.0225 - 0.04 * w, -0.01 * w, 0); O['tkR'].location = (0.0225 + 0.04 * w, 0.01 * w, 0)
    O['tkL'].rotation_euler = (0, 0, 0.3 * w); O['tkR'].rotation_euler = (0, 0, -0.25 * w)
    cam(mid + n * 0.26 + V(0.03, 0, 0.03), mid, 40)


@shot(k0('personne'), k0('ecris'), True)
def c4(t, u):
    quay_dark(); O['qlb0'].hide_render = False; O['qll0'].data.energy = 30 * (sin(t * 31) > -0.3)
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2), head=(0.3, 0, 0))); smile(1 - ease(u * 1.5))
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2), eo=1.3, brow=(0.45, 0.03)))
    face_cam('ctrl', 1.3, 0.0, -0.05, 36, 0.35, u)


@shot(k0('ecris'), TOTAL + 1, True)
def c5(t, u):
    quay_dark()
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2))); mo('ctrl', '18_01', 2.4, head_pitch=0.25); smile(1)
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2), eo=1.3, brow=(0.45, 0.03), arm=HOLD)); ticket_in_hand(1)
    campath((2.6, -2.8, 1.6), (2.2, -2.4, 1.55), (-0.5, 0.2, 1.1), (-0.5, 0.2, 1.1), u, 24, 26)


def reset_props():
    O['silseat'].hide_render = O['silseatb'].hide_render = False
    w = O['redwall']; w.visible_diffuse = False; w.visible_glossy = False
    O['ticket'].location = (0, 0, -60); O['ticket'].rotation_mode = 'XYZ'
    for s, nm in ((-1, 'L'), (1, 'R')):
        O['tk' + nm].location = (s * 0.0225, 0, 0); O['tk' + nm].rotation_euler = (0, 0, 0)
    O['tkhole'].hide_render = True
    for i in range(24): O['bdrop%d' % i].location = (0, 0, -60)
    for i in range(18): O['splat%d' % i].hide_render = True
    for i in range(16): O['spark%d' % i].location = (0, 0, -60)
    neons(0); O['emerg'].data.energy = 0; O['signt'].hide_render = False; O['tin'].data.energy = 300
    O['sun'].data.energy = 0


def apply(t):
    for a, b, f in SH:
        if a <= t < b:
            for nm in ('hero', 'dbl', 'ctrl'): pose2(nm, None)
            hide_misc(); reset_props()
            for nm in ('qll0', 'qll1'): O[nm].data.energy = 120
            O['shl'].data.energy = 35; O['qlb0'].hide_render = O['qlb1'].hide_render = False
            f(t, (t - a) / max(1e-3, b - a))
            return f.__name__
    return None


def pose_none_fix():
    pass


if __name__ == '__main__':
    mode = sys.argv[1]; sc = bpy.context.scene
    if mode == 'keys':
        sc.cycles.samples = 6
        os.makedirs('/kaggle/tmp/c/ep2/keys', exist_ok=True)
        sel = sys.argv[2].split(',') if len(sys.argv) > 2 else None
        for a, b, f in SH:
            if sel and f.__name__ not in sel: continue
            apply(a + (b - a) * 0.6)
            sc.render.filepath = '/kaggle/tmp/c/ep2/keys/%s.jpg' % f.__name__
            bpy.ops.render.render(write_still=True)
    else:
        sc.cycles.samples = 8; sc.cycles.diffuse_bounces = 1; sc.cycles.glossy_bounces = 1
        os.makedirs('/kaggle/tmp/c/ep2/fr', exist_ok=True)
        for f in range(int(sys.argv[2]), int(sys.argv[3])):
            p = '/kaggle/tmp/c/ep2/fr/%05d.jpg' % f
            t = f / 12.0
            if os.path.exists(p) or REW0 <= t < REW1: continue
            if apply(t) is None: continue
            sc.render.filepath = p; bpy.ops.render.render(write_still=True)
