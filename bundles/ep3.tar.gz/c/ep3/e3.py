import sys, os, math
sys.path.insert(0, '/kaggle/tmp/c/ep2')
_e = open('/kaggle/tmp/c/ep2/e2.py').read().replace('/kaggle/tmp/c/ep2/', '/kaggle/tmp/c/ep3/')
_e = _e.replace("sys.path.insert(0, '/kaggle/tmp/c/ep3')", "sys.path.insert(0, '/kaggle/tmp/c/ep2')")
exec(_e[:_e.index('SH = []\nREW0')])
exec(_e[_e.index('def reset_props'):_e.index('def apply')])
for k in ('09_01', '83_27'):
    CL[k] = MC.fk('/kaggle/tmp/c/mocap/%s.bvh' % k)

SH = []
DEATH0, REW0, REW1 = 14.05, 15.4, k0('dechire') - 0.05
PASS = ['p0', 'p1', 'p2', 'p3', 'p4']


def shot(a, b, ext=False):
    def deco(f):
        SH.append((a, b, f))
        if ext: EXT.add(f.__name__)
        return f
    return deco


HQ2 = V(0.0, 0.9, 0)
CTQ2 = V(-1.0, -0.5, 0)


def quay_dark():
    preset('quay')
    for nm in ('qll0', 'qll1', 'shl'): O[nm].data.energy = 0
    O['qlb0'].hide_render = O['qlb1'].hide_render = True
    O['signt'].hide_render = True
    O['camfill'].data.energy = 16
    O['shl'].data.energy = 9 * (0.4 + 0.6 * (math.sin(bpy.context.scene.frame_current * 1.7) > -0.7))


def torn(w=1.0, flip=0.0):
    upd(); hR = handp('hero', 'R'); hL = handp('hero', 'L'); mid = (hR + hL) / 2; hd = headp('hero')
    n = (hd - mid).normalized()
    O['ticket'].location = mid; O['ticket'].rotation_mode = 'XYZ'; O['ticket'].rotation_euler = n.to_track_quat('Z', 'Y').to_euler()
    O['tkL'].location = (-0.0225 - 0.04 * w, -0.01 * w, 0); O['tkR'].location = (0.0225 + 0.04 * w, 0.01 * w, 0)
    O['tkL'].rotation_euler = (0, 0, 0.3 * w); O['tkR'].rotation_euler = (0, 0, -0.25 * w)
    return mid, n


TEAR = {'R': (0.45, 0.0, 1.3), 'L': (0.45, -0.05, 1.3)}


# ------------------------------------------------------------- vote + death branch
@shot(0, k0('sidonne'), True)
def v0(t, u):
    quay_dark()
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1, head=(0.4, 0, 0), eo=1.1, brow=(-0.1, 0), arm=TEAR))
    mid, n = torn(1)
    cam(mid + n * 0.34 + V(0.03, 0, 0.03), mid, 38)


@shot(k0('sidonne'), k0('poinconne'), True)
def a1(t, u):
    quay_dark()
    w = ease(u * 1.4)
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2), eo=1.2, brow=(0.4, 0.02), arm={'R': (0.35 + 0.9 * w, -0.25, 1.35 - 1.0 * w)}))
    upd(); h = handp('hero', 'R'); O['ticket'].location = h + V(0, 0, 0.05); O['ticket'].rotation_euler = (0.3, 0, 0.6)
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2))); mo('ctrl', '18_01', 1.2 + 1.2 * u, head_pitch=0.2); smile(1)
    campath((1.0, -1.7, 1.45), (0.85, -1.45, 1.4), (-0.35, 0.4, 1.15), (-0.4, 0.35, 1.15), u, 24, 26)


@shot(k0('poinconne'), k0('ouvrent'), True)
def a2(t, u):
    quay_dark()
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2))); mo('ctrl', '18_01', 2.4, head_pitch=0.25); smile(1)
    upd(); hc = handp('ctrl', 'R')
    O['ticket'].location = hc + V(0, 0, 0.05); O['ticket'].rotation_mode = 'XYZ'; O['ticket'].rotation_euler = (0.3, 0, 0.6)
    O['tkhole'].hide_render = u < 0.5
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2), eo=1.2, brow=(0.4, 0.02)))
    campath(hc + V(0.35, -0.45, 0.25), hc + V(0.3, -0.4, 0.2), hc, hc, u, 35, 38)


@shot(k0('ouvrent'), k0('passagers'), True)
def a3(t, u):
    quay_dark(); O['tram'].location = (2.5, 3.1, 0); ext_doors(ease(u * 2)); O['tin'].data.energy = 800
    a = HQ2; b = V(-0.05, 2.6, 0); pos = a.lerp(b, ease((u - 0.3) / 0.7))
    walkclip('hero', pos, pi, (t - k0('ouvrent')) * 0.8); face('hero', 1.0, (0.3, 0))
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, pos))); smile(1)
    campath((-0.4, -2.4, 1.5), (-0.3, -1.9, 1.45), (0, 2.2, 1.3), (0, 2.6, 1.3), u, 26, 30)


PSEATS = [(X - 5.0, 0.78), (X - 3.5, -0.78), (X - 0.5, 0.78), (X + 1.0, -0.78), (X - 6.5, -0.78)]


def passengers(turn=0.0, t=0.0):
    for i, nm in enumerate(PASS):
        x, y = PSEATS[i]
        look = yaw_to((x, y), (X + 2.6, 0.0)) - pi / 2
        hy = max(-2.4, min(2.4, look)) * ease(turn)
        pose2(nm, P(loc=(x, y, -0.05), yaw=pi / 2, sit=1, spine=0.2 * (1 - turn), head=(0.5 * (1 - ease(turn)) + 0.05, hy, 0)))
        O[nm + '_hips'].location.z = 0.85
    dbl_back()


@shot(k0('passagers'), k0('tournent'))
def a4(t, u):
    preset('tram'); flick(t, 1, 0.2); passengers(0)
    campath((X + 2.8, 0.0, 1.45), (X + 1.6, 0.0, 1.4), (X - 6, 0.0, 1.0), (X - 6, 0.0, 0.95), u, 24, 26)


@shot(k0('tournent'), DEATH0)
def a5(t, u):
    preset('tram'); flick(t, 1, 0.5); passengers(min(1, u * 3.5) if u > 0.2 else 0)
    campath((X + 1.5, 0.0, 1.4), (X + 1.2, 0.0, 1.38), (X - 4, 0.0, 1.0), (X - 4, 0.0, 1.0), u, 24, 28)


@shot(DEATH0, REW0)
def dd(t, u):
    preset('tram'); neons(4); O['camfill'].data.energy = 0; O['sun'].data.energy = 0
    for i in range(4): O['til%d' % i].data.energy = 0
    O['silseat'].hide_render = O['silseatb'].hide_render = True
    XS = 700
    pull = ease(u / 0.5); fall = ease((u - 0.35) / 0.4)
    pose2('hero', P(loc=(XS - 0.5, 0.6, -0.5 * fall), yaw=pi / 2 * 0.0, spine=-0.2 - 0.6 * fall, head=(-0.5 * fall, 0.3, 0),
                    arm={'L': (2.8 - 1.0 * fall, 0.9, 0.2), 'R': (2.6 - 0.8 * fall, 0.9, 0.3)}, leg={'L': (0.4 * fall, 0.9 * fall), 'R': (0.3 * fall, 0.7 * fall)}))
    spots = [(-1.3, 0.4, 0.5, 1), (0.3, 0.4, -0.5, -1), (-1.0, 0.9, 0.9, 1), (0.1, 0.9, -0.9, -1)]
    for nm, (dx, dy, yw, s) in zip(PASS, spots):
        pose2(nm, P(loc=(XS - 0.5 + dx + 0.25 * s * pull, dy, 0), yaw=-pi / 2 * s + yw * 0.3, spine=0.3 + 0.4 * pull,
                    arm={'L': (1.6 - 0.8 * pull, 0.2, 0.5), 'R': (1.4 - 0.7 * pull, -0.2, 0.6)}, head=(0.3, 0, 0)))
    if u > 0.45:
        s = (u - 0.45) / 0.55
        for i in range(24):
            a = i * 2.39; sp = 0.6 + (i % 5) * 0.25
            O['bdrop%d' % i].location = (XS - 0.5 + cos(a) * sp * s * 1.3, 0.5 - sp * s * 0.6, 0.9 + sin(a) * sp * s - 2.5 * s * s)
        for i in range(18):
            O['splat%d' % i].hide_render = s < (i % 6) * 0.06
    cam((XS - 0.5, -3.4, 0.75), (XS - 0.5, 0.5, 1.0), 30, shake=0.05 if 0.4 < u < 0.6 else 0, t=t * 3)


# ------------------------------------------------------------- survival
@shot(REW1, k0('morceaux'), True)
def b1(t, u):
    quay_dark()
    w = 0.6 + 0.4 * ease(u)
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1, head=(0.4, 0, 0), eo=1.2, brow=(-0.2, 0.0), arm=TEAR))
    mid, n = torn(w)
    cam(mid + n * 0.3 + V(0.04, 0, 0.03), mid, 38)


@shot(k0('morceaux'), k0('fige'), True)
def b2(t, u):
    quay_dark()
    pose2('hero', P(loc=HQ2, yaw=-pi * 0.1, head=(0.5, 0, 0), eo=1.0, brow=(0.2, 0.0), arm={'R': (0.3, 0.1, 0.4), 'L': (0.3, 0.1, 0.4)}))
    fall = ease(u * 1.3)
    O['ticket'].location = V(0.05, 0.6, 0.95 * (1 - fall) + 0.01); O['ticket'].rotation_mode = 'XYZ'
    O['ticket'].rotation_euler = (1.2 * (1 - fall), 0.4 * sin(t * 5) * (1 - fall), t * 0.8)
    O['tkL'].location = (-0.0225 - 0.12 * fall, -0.05 * fall, 0); O['tkR'].location = (0.0225 + 0.15 * fall, 0.06 * fall, 0)
    O['tkL'].rotation_euler = (0, 0, 0.5 + 2 * fall); O['tkR'].rotation_euler = (0, 0, -0.4 - 1.5 * fall)
    campath((0.5, -0.5, 0.15), (0.45, -0.4, 0.12), (0.05, 0.6, 0.2), (0.05, 0.6, 0.02), u, 30, 34)


@shot(k0('fige'), k0('sans'), True)
def b3(t, u):
    quay_dark()
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2), head=(0.15, 0, 0))); mo('ctrl', '18_01', 2.4, head_pitch=0.15); smile(1 - ease((u - 0.35) / 0.4))
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2), eo=1.3, brow=(0.45, 0.03)))
    face_cam('ctrl', 1.3, 0.05, -0.05, 36, 0.3, u)


@shot(k0('sans'), k0('vitre'), True)
def b4(t, u):
    quay_dark(); O['shl'].data.energy = 9 * (sin(t * 29) > -0.2)
    pose2('ctrl', P(loc=CTQ2, yaw=yaw_to(CTQ2, HQ2), head=(0.3, 0.0, 0.25 * ease(u)))); smile(0)
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2), eo=1.4, brow=(0.5, 0.04)))
    face_cam('ctrl', 1.35, -0.1, 0.05, 38, 0.25, u)


def mirror_tram(on=True):
    m = bpy.data.materials['tramwin'].node_tree.nodes['Principled BSDF']
    m.inputs['Emission Strength'].default_value = 0.0 if on else 2.2
    m.inputs['Roughness'].default_value = 0.02 if on else 0.1
    m.inputs['Metallic'].default_value = 0.85 if on else 0.0
    O['tin'].data.energy = 0 if on else 300


def hero_invisible_in_mirror(v=True):
    for o in O:
        if o.name.startswith('hero_'):
            o.visible_glossy = not v


@shot(k0('vitre'), k0('reflet'), True)
def b5(t, u):
    quay_dark(); O['tram'].location = (2.5, 3.1, 0); mirror_tram(True); hero_invisible_in_mirror(True)
    pose2('hero', P(loc=HQ2, yaw=yaw_to(HQ2, CTQ2) + (pi - yaw_to(HQ2, CTQ2)) * ease(u * 1.3), eo=1.2, brow=(0.4, 0.02)))
    pose2('ctrl', P(loc=V(-0.6, -0.4, 0), yaw=yaw_to((-0.6, -0.4), HQ2))); smile(0)
    campath((1.4, -0.4, 1.2), (1.2, -0.3, 1.2), (0, 0.9, 1.1), (0, 1.0, 1.1), u, 30, 34)


@shot(k0('reflet'), k0('cours'), True)
def b6(t, u):
    quay_dark(); O['tram'].location = (2.5, 3.1, 0); mirror_tram(True); hero_invisible_in_mirror(True)
    O['shl'].data.energy = 14
    pose2('hero', P(loc=V(0.0, 1.25, 0), yaw=pi, eo=1.4, brow=(0.5, 0.04)))
    pose2('ctrl', P(loc=V(-0.4, -0.3, 0), yaw=yaw_to((-0.4, -0.3), HQ2))); smile(ease(u))
    campath((0.35, 0.2, 1.4), (0.3, 0.45, 1.38), (0.05, 1.86, 1.35), (0.0, 1.86, 1.4), u, 30, 34)


@shot(k0('cours'), k0('haut'), True)
def b7(t, u):
    quay_dark(); O['tram'].location = (2.5, 3.1, 0); mirror_tram(True)
    a = V(0, 0.5, 0); b = V(-11.0, -3.5, 0); pos = a.lerp(b, u)
    pose2('hero', P(loc=pos, yaw=yaw_to(a, b))); mo('hero', '09_01', 0.1 + ((t * 1.1) % 0.95)); face('hero', 1.4, (0.5, 0.04), 0.4)
    campath((-14, -3.2, 2.8), (-13.5, -3.3, 2.7), pos + V(0, 0, 1.0), pos + V(0, 0, 1.0), u, 28, 30)


XS2 = 900


def street():
    preset('quay'); O['camfill'].data.energy = 12; O['roomlight'].data.energy = 0


@shot(k0('haut'), k0('fenetre'), True)
def b8(t, u):
    street()
    a = V(XS2 - 6, 2.6, 0); b = V(XS2 - 4.5, 1.2, 0); pos = a.lerp(b, ease(u))
    walkclip('hero', pos, yaw_to(a, b) * (1 - u) + yaw_to(b, (XS2, 6.5)) * u, (t - k0('haut')) * 0.8, head_pitch=-0.25)
    face('hero', 1.2, (0.4, 0.02))
    campath((XS2 - 2.0, -4.5, 1.2), (XS2 - 2.5, -4.0, 1.3), (XS2 - 1.5, 6.5, 4.0), (XS2 - 1, 6.5, 5.0), u, 22, 24)


@shot(k0('fenetre'), k0('rideau'), True)
def b9(t, u):
    street()
    pose2('hero', P(loc=V(XS2 - 4.5, 1.2, 0), yaw=yaw_to((XS2 - 4.5, 1.2), (XS2, 6.5)), head=(-0.5, 0, 0), eo=1.2, brow=(0.4, 0.02)))
    campath((XS2 - 1.5, 1.0, 1.7), (XS2 - 1.0, 1.8, 2.3), (XS2, 6.5, 7.2), (XS2, 6.5, 7.0), u, 30, 40)


@shot(k0('rideau'), k0('vingt'), True)
def b10(t, u):
    street()
    pose2('dbl', P(loc=V(XS2 + 0.1 - 0.2 * u, 6.9, 6.56), yaw=pi + 0.3 * sin(t * 0.7), head=(0.1, 0.2 * sin(t), 0)))
    O['dbl_hips'].location.z = 0.85; O['camfill'].data.energy = 0
    campath((XS2 - 0.3, 2.6, 6.5), (XS2 - 0.2, 3.6, 6.8), (XS2, 6.6, 7.15), (XS2, 6.6, 7.15), u, 35, 40)


@shot(k0('vingt'), k0('un'), True)
def b11(t, u):
    street()
    pose2('hero', P(loc=V(XS2 - 4.5, 1.2, 0), yaw=yaw_to((XS2 - 4.5, 1.2), (XS2, 6.5)), head=(-0.45, 0, 0), eo=1.4, brow=(0.5, 0.04)))
    face_cam('hero', 1.0, 0.1, -0.15, 40, 0.2, u)


XB = 1000


def bedroom():
    preset('tram'); O['camfill'].data.energy = 8


@shot(k0('un'), k0('ouvres'))
def c1(t, u):
    bedroom()
    a = V(XB - 2.8, -0.6, 0); b = V(XB - 0.3, -0.55, 0); pos = a.lerp(b, u)
    walkclip('hero', pos, pi / 2, (t - k0('un')) * 0.8); face('hero', 1.2, (0.4, 0.02))
    pose2('dbl', P(loc=V(XB, 4.0, 0), yaw=pi, head=(0.05, 0, 0)))
    campath((XB + 1.6, -0.75, 1.5), (XB + 1.3, -0.7, 1.45), pos + V(0, 0, 1.0), pos + V(0, 0, 1.0), u, 26, 28)


@shot(k0('ouvres'), k0('vrai'))
def c2(t, u):
    bedroom()
    O['brdoorh'].rotation_euler = (0, 0, 1.6 * ease((u - 0.15) / 0.6))
    pose2('hero', P(loc=V(XB - 0.1, -0.55, 0), yaw=pi, eo=1.3, brow=(0.45, 0.03), arm={'R': (1.2 * (1 - ease((u - 0.5) / 0.3)), -0.1, 0.4)}))
    pose2('dbl', P(loc=V(XB, 4.0, 0), yaw=pi, head=(0.05, 0, 0)))
    campath((XB + 0.5, -1.05, 1.55), (XB + 0.35, -0.95, 1.5), (XB - 0.1, 2.0, 1.2), (XB, 4.0, 1.2), u, 26, 30)


@shot(k0('vrai'), k0('deux'))
def c3(t, u):
    bedroom(); O['brdoorh'].rotation_euler = (0, 0, 1.6)
    pose2('dbl', P(loc=V(XB, 4.0, 0), yaw=pi + pi * ease((u - 0.2) / 0.6), head=(0.15, 0, 0)))
    pose2('hero', P(loc=V(XB - 0.1, 0.4, 0), yaw=pi, eo=1.4, brow=(0.5, 0.04)))
    h = headp('dbl')
    campath(h + V(0.2, -2.0, -0.1), h + V(0.15, -1.3, -0.1), h, h, u, 32, 36)


@shot(k0('deux'), k0('attends'), True)
def d1(t, u):
    quay_dark(); mirror_tram(False)
    a = V(-11.0, -3.5, 0); b = V(-3, 0.6, 0); pos = a.lerp(b, u)
    walkclip('hero', pos, yaw_to(a, b), (t - k0('deux')) * 0.8); face('hero', 1.0, (0.3, 0))
    campath((-3.5, -0.3, 1.4), (-3.2, -0.1, 1.4), pos + V(0, 0, 1.0), pos + V(0, 0, 1.0), u, 26, 28)


@shot(k0('attends'), k0('ctrl'), True)
def d2(t, u):
    quay_dark(); O['tram'].location = (60 - 30 * ease(u), 3.1, 0)
    pose2('hero', P(loc=V(0, 1.2, 0), yaw=pi / 2, head=(0, 0, 0), eo=1.1, brow=(0.35, 0.01)))
    campath((-2.5, 0.0, 1.3), (-2.2, 0.1, 1.3), (20, 3.1, 1.2), (14, 3.1, 1.2), u, 30, 34)


@shot(k0('ctrl'), k0('ecris'), True)
def d3(t, u):
    quay_dark(); O['tram'].location = (30 - 8 * u, 3.1, 0)
    pose2('hero', P(loc=V(0, 1.2, 0), yaw=pi / 2, head=(0, 0, 0), eo=1.1, brow=(0.35, 0.01)))
    c = V(-0.9, 0.4, 0); pose2('ctrl', P(loc=c, yaw=yaw_to(c, (0, 1.2)), head=(0.25, 0, 0))); smile(ease(u * 1.5))
    h = headp('hero')
    campath(h + V(1.3, -0.5, -0.05), h + V(1.0, -0.4, -0.05), h + V(-0.4, -0.3, 0), h + V(-0.4, -0.3, 0), u, 32, 36)


@shot(k0('ecris'), TOTAL + 1, True)
def e1(t, u):
    quay_dark(); O['tram'].location = (22 - 4 * u, 3.1, 0); O['shl'].data.energy = 12
    pose2('hero', P(loc=V(0, 1.2, 0), yaw=pi / 2, eo=1.1, brow=(0.35, 0.01)))
    c = V(-0.9, 0.4, 0); pose2('ctrl', P(loc=c, yaw=yaw_to(c, (0, 1.2)), head=(0.25, 0, 0))); smile(1)
    campath((3.0, -2.6, 1.7), (2.6, -2.2, 1.6), (-0.4, 0.8, 1.0), (-0.4, 0.8, 1.0), u, 24, 26)


def apply(t):
    for a, b, f in SH:
        if a <= t < b:
            for nm in ['hero', 'dbl', 'ctrl'] + PASS: pose2(nm, None)
            hide_misc(); reset_props(); mirror_tram(False); hero_invisible_in_mirror(False)
            O['brdoorh'].rotation_euler = (0, 0, 0)
            for nm in ('qll0', 'qll1'): O[nm].data.energy = 120
            O['shl'].data.energy = 35; O['qlb0'].hide_render = O['qlb1'].hide_render = False
            f(t, (t - a) / max(1e-3, b - a))
            return f.__name__
    return None


if __name__ == '__main__':
    mode = sys.argv[1]; sc = bpy.context.scene
    if mode == 'keys':
        sc.cycles.samples = 6
        os.makedirs('/kaggle/tmp/c/ep3/keys', exist_ok=True)
        sel = sys.argv[2].split(',') if len(sys.argv) > 2 else None
        for a, b, f in SH:
            if sel and f.__name__ not in sel: continue
            apply(a + (b - a) * 0.6)
            sc.render.filepath = '/kaggle/tmp/c/ep3/keys/%s.jpg' % f.__name__
            bpy.ops.render.render(write_still=True)
    else:
        sc.cycles.samples = 8; sc.cycles.diffuse_bounces = 1; sc.cycles.glossy_bounces = 1
        os.makedirs('/kaggle/tmp/c/ep3/fr', exist_ok=True)
        for f in range(int(sys.argv[2]), int(sys.argv[3])):
            p = '/kaggle/tmp/c/ep3/fr/%05d.jpg' % f
            t = f / 12.0
            if os.path.exists(p) or REW0 <= t < REW1: continue
            if apply(t) is None: continue
            sc.render.filepath = p; bpy.ops.render.render(write_still=True)
